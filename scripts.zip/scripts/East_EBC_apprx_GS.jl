#   ===================================================
using SparseArrays, LinearAlgebra, Random, Optim, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")  # loads the file with ground state functions
using .GSModule         # dot means “from current project/folder”
#   ===================================================
#=
    ⋅   1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
    ⋅   Find spin-coherent state |C⟩ = ⊗ᵢ |θ⟩ᵢ, where |θ⟩ = cos(θ/2)|1⟩ + sin(θ/2)|0⟩ closest to ground state

    ---Parameter descriptions---
    L = Number of particles
    s = system parameter
=#
#   ===================================================
#   Define functions
#   ===================================================
#   Polarized spin-coherent state: H_EastModule.f_spin_pol_state
#   ===================================================
#   End of function definitions
#   ===================================================
ftype = "East_apprx_GS";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   System parameters
s_arr = vcat(collect(-1:0.1:-0.1), collect(-0.08:0.02:0.08), collect(0.1:0.1:1));
#   Save s values
fname_s_vals = @sprintf("%s_%02d.dat", "s_vals", L);
writedlm(fname_s_vals, s_arr, '\t');
#   ===================================================
#   Internal parameters
const Nv = 8;   #   Number of repetitions for m-step Lanczos
const m = 16;   #   Number of Lanczos steps
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);

a_wall = Array{Float64}(undef, m_wall);
#   ======================================
#   Filenames
#   ======================================
fname = @sprintf("%s_%s_%02d.dat", ftype, "E_GS", L);
fid = open(fname, "w");
#   ======================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = GSModule.f_wall_node(m_wall);
    #   ==================================
    #   Off-diagonal part of East Hamiltonian
    H_East = H_EastModule.f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s);

        #   Update diagonal part of East Hamiltonian
        global E_East, H_East;
        H_EastModule.f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Estimate energy bounds from m-step Lanczos reduction
        global v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm;
        E_low, E_up = GSModule.f_E_bound_Lanczos!(N_H, m, Nv, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm);
        
        #   Ground state energy using wall-Chebyshev method
        global a_wall;
        EG, j_wall = GSModule.f_Wall!(Γ, E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1);

        #   Spin-coherent approximation
        #   Ground state energy ansatz
        f(x) = 1/2 + (L/2) * cos(x/2)^2 - (exp(-s)/2) * ( sin(x) + (L-1)*(1+cos(x))*sin(x)/2 + (1 + cos(x)) / 2 )

        #   Initial guess for θ = π/3
        res = optimize(f, 0, 2*π)

        theta_min = Optim.minimizer(res)
        E_min = Optim.minimum(res)

        # println("Minimum at: ", theta_min)
        # println("Minimum value: ", E_min, ",\t actual EG: ", EG)

        #   Create the spin-coherent state vector
        v1 .= f_spin_pol_state(L, theta_min);

        #   Overlap between ground state and spin-coherent state, |<GS|ψ>|² (squared, as in all other scripts)
        overlap = abs2(dot(v0, v1));
        # println("Overlap between ground state and spin-coherent state: ", overlap)

        writedlm(fid, [s EG theta_min E_min overlap], '\t');
    end                     #   Loop for system parameter closed
    close(fid);
end;
#   ======================================
"""
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
"""