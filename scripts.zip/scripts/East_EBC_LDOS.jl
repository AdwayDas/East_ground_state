include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
include("/home/adway/01.Works/01.CPU/21.East/scripts/DynamicsModule.jl")
using .H_EastModule, .DynamicsModule, LinearAlgebra, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition
    ⋅   LDOS of edge mode

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   System parameters
s_arr = [-4; -1; -0.2; 0; 0.1; 0.2; 0.4; 1];

#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
writedlm(fname_s_vals, s_arr, '\t');

#   ===================================================
#   Internal parameters
const Nv = 64;      #   Number of stochastic samplings
#   Number of Lanczos steps
const m = max( 256, convert(Int64, floor(sqrt(N_H))) );
#   Number of points in the energy axis
const lEx = 64;
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);

#   Arrays for DOS
E_edge = Array{Float64}(undef, lEx+1);
Ex = Array{Float64}(undef, lEx);
Ey = zeros(lEx);
z_wght = Array{Float64}(undef, m);
#   ======================================

stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    #   Spin-coherent state: edge mode for s -> -∞
    #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
    theta_arr = zeros(L); fill!(theta_arr, π/3); theta_arr[1] = 4*π/3
    Ψ = f_spin_c_state(L, theta_arr);
    
    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s); println("s: ", s);

        #   Update diagonal part of East Hamiltonian
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   DOS from m-step Lanczos reduction
        global v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm, Ex, E_edge, z_wght, Ey;
        global v0 = copy(Ψ);
        f_LDOS_Lanczos!(N_H, m, Nv, lEx, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm, Ex, Ey, E_edge, z_wght);
        #   Accounting for global factor in the Hamiltonian
        Ex ./= 2*Γ; Ey .*= 2*Γ;

        #   Filename
        fname_LDOS = @sprintf("%s_%s_%02d_%+05.2f.dat", ftype, "LDOS_spin-c", L, s);
        writedlm(fname_LDOS, [Ex Ey], '\t');
    end
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end