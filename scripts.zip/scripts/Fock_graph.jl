using LinearAlgebra, SparseArrays, Graphs, CairoMakie
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule

# -----------------------------
# Basis utilities
# -----------------------------
#   Site 1 (bit 0) leftmost, as in H_EastModule
bitstring_state(s, L) = join([isone((s >> i) & 1) ? "↑" : "↓" for i in 0:L-1])

nup(s) = count_ones(s)

function fock_basis(L)
    return collect(0:2^L-1)
end

# -----------------------------
# Example Hamiltonian: transverse-field Ising-like connectivity
# H = -J Σ σᶻᵢ σᶻᵢ₊₁ - h Σ σˣᵢ
# Only σˣ terms change the Fock-state graph connectivity
# -----------------------------
function tfim_hamiltonian(L; J=1.0, h=1.0)
    dim = 2^L
    H = spzeros(Float64, dim, dim)

    for s in 0:dim-1
        i = s + 1

        # diagonal Ising term
        for site in 0:L-2
            zi  = iszero((s >> site) & 1) ? -1 : 1
            zip = iszero((s >> (site+1)) & 1) ? -1 : 1
            H[i,i] += -J * zi * zip
        end

        # off-diagonal spin flips: σˣ
        for site in 0:L-1
            s2 = xor(s, 1 << site)
            j = s2 + 1
            H[j,i] += -h
        end
    end

    return H
end

#   East Hamiltonians: f_H_East_EBC_off, f_H_East_PBC_L, f_H_East_EBC_update_diag! from H_EastModule

# -----------------------------
# Build Fock-space graph from H
# -----------------------------
function fock_graph_from_H(H; tol=1e-12)
    dim = size(H, 1)
    g = SimpleGraph(dim)

    for i in 1:dim
        for j in i+1:dim
            if abs(H[i,j]) > tol || abs(H[j,i]) > tol
                add_edge!(g, i, j)
            end
        end
    end

    return g
end

# -----------------------------
# Manual layout: column = number of ↑ spins
# -----------------------------
function fock_layout(L)
    basis = fock_basis(L)

    xs = Float64[]
    ys = Float64[]

    for s in basis
        k = nup(s)
        states_in_column = filter(x -> nup(x) == k, basis)
        idx = findfirst(==(s), states_in_column)
        ncol = length(states_in_column)

        push!(xs, k)
        push!(ys, idx - (ncol + 1)/2)
    end

    return xs, ys
end

# -----------------------------
# Plot
# -----------------------------
L = 4
N_H = 2^L
Γ = 0.5
H = tfim_hamiltonian(L; J=1.0, h=1.0)
#   Off-diagonal part of East Hamiltonian
H_East = f_H_East_PBC_L(L, N_H);
#   Update diagonal part of East Hamiltonian
E_East = zeros(N_H)
f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

g = fock_graph_from_H(H_East)

basis = fock_basis(L)
labels = [bitstring_state(s, L) for s in basis]
xs, ys = fock_layout(L)

fig = Figure(size=(900, 600))
ax = Axis(
    fig[1,1],
    xlabel = "",
    ylabel = "",
    title = "",
    # xticks = 0:L,
    yticksvisible = false,
    yticklabelsvisible = false
)

# draw edges
for e in edges(g)
    i = src(e)
    j = dst(e)
    lines!(ax, [xs[i], xs[j]], [ys[i], ys[j]], color=:gray, linewidth=2)
end

# draw nodes
scatter!(ax, xs, ys, markersize=18, color=:dodgerblue)

# labels
for i in eachindex(labels)
    text!(
        ax,
        labels[i],
        position=(xs[i] + 0.05, ys[i]),
        fontsize=20,
        align=(:left, :center)
    )
end

xlims!(ax, -0.5, L + 0.5)
#   Remove plot box
hidespines!(ax)
hidedecorations!(ax)

fig

save("Fock_graph_East.pdf", fig)
