#   ===================================================
using SparseArrays, Arpack, LinearAlgebra, Random, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule

include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")  # loads the file with ground state functions
using .GSModule         # dot means “from current project/folder”
#   ===================================================
#=
    ⋅   1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
    ⋅   Few eigenvalues from the middle of the spectrum

    ---Parameter descriptions---
    L = Number of particles
    s = system parameter
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);    #   Number of sites
const nev = 2^10;                   #   Number of eigenvalues obtained

#   System parameters
s_arr = -1:0.1:0.5
# vcat(collect(-1:0.1:-0.1), collect(-0.08:0.02:0.08), collect(0.1:0.1:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
fid_s_vals = open(fname_s_vals, "w");
writedlm(fid_s_vals, s_arr, '\t'); close(fid_s_vals);

#   Hilbert space dimension
const N_H = 2^L;
#   ===================================================
#   Internal parameters
const Nv = 8;   #   Number of repetitions for m-step Lanczos
const m = 16;   #   Number of Lanczos steps
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
#   Preallocate arrays
ax = Array{Int64}(undef, 2^L);
j0 = Array{Int64}(undef, 2^(L-1));
j1 = Array{Int64}(undef, 2^(L-1));
k_ind = Array{Int64}(undef, 2^(L-2));
l_ind = Array{Int64}(undef, 2^(L-2));

E_East = zeros(N_H);
#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);
#   ======================================
stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s);
        @printf("s: %+5.2f\n", s);

        #   Update diagonal part of East Hamiltonian
        global E_East, ax, j1, H_East;
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Estimate energy bounds from m-step Lanczos reduction
        global v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm;
        E_low, E_up = f_E_bound_Lanczos!(N_H, m, Nv, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm);
        E_mid = (E_low + E_up)/2;

        #   nev number of eigenvalues from the middle of the spectrum: Shift-invert
        E_arr, v = eigs(H_East, nev=nev, which=:LM, tol=0.0, sigma=E_mid, ritzvec=false);
        #   Overall multiplicative factor
        E_arr ./= 2*Γ;

        #   Printing data
        fname_E_mid = @sprintf("%s_%s_%02d_%+05.2f.dat", ftype, "E_mid", L, s);
        fid_E_mid = open(fname_E_mid, "w");
        writedlm(fid_E_mid, E_arr, '\t');
        close(fid_E_mid);
    end                     #   Loop for system parameter closed
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
