#   ===================================================
using SparseArrays, LinearAlgebra, Random, Optim, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")
using .GSModule
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Checking if ground state is close to a spin-coherent state |C⟩ = ⊗ᵢ |θ⟩ᵢ, where |θ⟩ = cos(θ/2)|1⟩ + sin(θ/2)|0⟩

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
#   Ground state energy ansatz
#   ===================================================
function f_E_GS_ansatz(θ::Vector{Float64})
    L = length(θ)
    E_GS = 0.0
    @inbounds for i in 1:L-1
        #   - <nᵢ><σˣᵢ₊₁>
        E_GS -= (1+cos(θ[i]))*sin(θ[i+1])/2
    end

    #   East boundary term: - <n_L>
    E_GS -= (1 + cos(θ[L])) / 2
    #   <σˣ₁>
    E_GS -= sin(θ[1])

    return E_GS
end
#   Spin-coherent state: H_EastModule.f_spin_c_state (θ[i] on site i)
#   ===================================================
#   End of function definitions
#   ===================================================
ftype = "East_L_apprx_GS";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;
#   ===================================================
#   Internal parameters
m = 16;   #   Number of Lanczos steps
Nv = 8;   #   Number of repetitions for m-step Lanczos
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
stats = @timed begin
    #   Initial guess for θᵢ
    theta_arr = zeros(L); fill!(theta_arr, π/3);

    res = optimize(f_E_GS_ansatz, theta_arr, NelderMead())

    theta_min = Optim.minimizer(res)
    E_min = Optim.minimum(res)

    # println("Minimum at: ", theta_min)
    # println("Minimum value: ", E_min)

    fname_theta = @sprintf("%s_%s_%02d.dat", ftype, "theta", L);
    writedlm(fname_theta, theta_min, '\t');

    #   Off-diagonal part of East Hamiltonian
    H_East = H_EastModule.f_H_East_EBC_L_off(L, N_H);
    #   Update diagonal part of East Hamiltonian
    E_East = zeros(Float64, N_H);
    H_EastModule.f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);

    #   Estimate energy bounds from m-step Lanczos reduction
    #   Arrays for Lanczos algorithm
    Qm = Array{Float64}(undef, N_H, m);
    v0 = Array{Float64}(undef, N_H);
    v1 = Array{Float64}(undef, N_H);
    vk = Array{Float64}(undef, N_H);
    pot = Array{Float64}(undef, m);
    hop = Array{Float64}(undef, m);
    Tm = SymTridiagonal(pot, hop[1:m-1]);
    E_Tm = Array{Float64}(undef, m);
    V_Tm = Array{Float64}(undef, m, m);

    E_low, E_up = GSModule.f_E_bound_Lanczos!(N_H, m, Nv, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm);
    
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = GSModule.f_wall_node(m_wall);
    a_wall = Array{Float64}(undef, m_wall);

    #   Ground state energy using wall-Chebyshev method
    EG, j_wall = GSModule.f_Wall!(0.5, E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1);
    # println("Ground state energy from exact diagonalization: ", EG)

    #   Create the spin-coherent state vector
    v1 .= H_EastModule.f_spin_c_state(L, theta_min);

    #   Overlap between ground state and spin-coherent state, |<GS|ψ>|² (squared, as in all other scripts)
    overlap = abs2(dot(v0, v1));
    # println("Overlap between ground state and spin-coherent state: ", overlap)
    fname = @sprintf("%s_%s_%02d.dat", ftype, "E_overlap", L);
    writedlm(fname, [EG, E_min, overlap], '\t');
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end