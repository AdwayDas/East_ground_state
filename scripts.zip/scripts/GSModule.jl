module GSModule

#   Ground state observables
export f_E_bound_Lanczos!, f_wall_node, f_Wall!,
f_num_dnsty!, f_dnsty_corr!, f_sx_avg!, f_Dq!, f_SvN!, f_SvN_all,
trnsfrm_sz_to_sx!, f_GS_chi!

using SparseArrays, LinearAlgebra, Random, LinearMaps, IterativeSolvers

const INV_SQRT2 = 1 / sqrt(2)
#   ===================================================
#   Estimate lower and upper energy bound from m-step Lanczos reduction
#   ===================================================
function f_E_bound_Lanczos!(N::Int, m::Int, 
    Nv::Int,                # number of initial random vectors
    H::SparseMatrixCSC{Float64,Int},
    v0::Vector{Float64}, v1::Vector{Float64}, vk::Vector{Float64},
    Qm::Matrix{Float64},    #   orthonormal basis in m-dim Lanczos space
    pot::Vector{Float64},   #   diagonal Lanczos coefficients
    hop::Vector{Float64},   #   off-diagonal Lanczos coefficients
    Tm::SymTridiagonal{Float64,Vector{Float64}}, #  Tridiagonal matrix from Lanczos reduction
    E_Tm::Vector{Float64}, V_Tm::Matrix{Float64}
)
    E_up_arr  = similar(E_Tm, Nv)
    E_low_arr = similar(E_Tm, Nv)

    diagT = Tm.dv        # diagonal
    offT  = Tm.ev        # off-diagonal (length m-1)

    @inbounds for jv in 1:Nv

        # --- initial random vector ---
        randn!(v0)
        normalize!(v0)
        @views copyto!(Qm[:,1], v0)

        # vk = H * v0
        mul!(vk, H, v0)

        ak = dot(v0, vk)
        pot[1] = ak

        @inbounds @simd for i in 1:N
            vk[i] -= ak * v0[i]
        end

        bk = norm(vk)
        hop[1] = bk

        copyto!(v1, v0)   # store q_{j-1}

        # --- Lanczos loop ---
        for j in 2:m
            # q_j = vk / b_{j-1}
            @inbounds @simd for i in 1:N
                v0[i] = vk[i] / bk
            end
            @views copyto!(Qm[:, j], v0)

            # vk = H * q_j
            mul!(vk, H, v0)

            # vk -= b_{j-1} * q_{j-1}
            @inbounds @simd for i in 1:N
                vk[i] -= bk * v1[i]
            end

            # a_j = q_j ⋅ vk
            ak = dot(v0, vk)
            pot[j] = ak

            # vk -= a_j * q_j
            @inbounds @simd for i in 1:N
                vk[i] -= ak * v0[i]
            end

            # full reorthogonalization
            @inbounds for iQ in 1:(j-1)
                @views q = Qm[:, iQ]
                c = dot(q, vk)
                @inbounds @simd for k in 1:N
                    vk[k] -= c * q[k]
                end
            end

            # next b_j
            bk = norm(vk)
            hop[j] = bk

            # shift q_{j-1} ← q_j
            copyto!(v1, v0)
        end

        # --- build Tm in-place ---
        @inbounds for i in 1:m
            diagT[i] = pot[i]
        end
        @inbounds for i in 1:(m-1)
            offT[i] = hop[i]
        end

        # eigen-decomposition of Tm
        eig = eigen!(Tm)
        @inbounds copyto!(E_Tm, eig.values)
        @inbounds copyto!(V_Tm, eig.vectors)

        # upper / lower bounds
        E_up_arr[jv]  = E_Tm[m] + hop[m] * abs(V_Tm[m,m])
        E_low_arr[jv] = E_Tm[1] - hop[m] * abs(V_Tm[m,1])
    end

    return minimum(E_low_arr), maximum(E_up_arr)
end
#   ===================================================
#   Wall-Chebyshev nodes
#   ===================================================
function f_wall_node(m_wall::Int64)
    #=
    ⋅   m_wall = number of wall-Chebyshev coefficients
    =#
    return 1 .- cos.(pi.*(1:m_wall)./(m_wall + 0.5));
end
#   ===================================================
#   Ground state energy using wall-Chebyshev method
#   ===================================================
function f_Wall!(Γ::Float64, E_low::Float64, E_up::Float64, E_tol::Float64, m_wall::Int64, n_wall::Int64,
    H::SparseMatrixCSC{Float64, Int64}, a_wall_scld::Array{Float64}, a_wall::Array{Float64}, v0::Array{Float64}, vG::Array{Float64})
    #   Initial vector
    randn!(v0); normalize!(v0);

    #   Initial estimate of ground state energy, <Ψ|H|Ψ>
    mul!(vG, H, v0); EG = dot(vG, v0);

    #   Loop for iteration
    j_wall = 0; E0 = E_low;
    while abs(E0 - EG) > E_tol && j_wall < n_wall
        E0 = EG;
        #   Wall-Chebyshev nodes
        copyto!(a_wall, a_wall_scld);
        a_wall .*= (E_up - E_low)/2; a_wall .+= EG;

        v0 .*= a_wall[1];
        vG .-= v0;
        normalize!(vG); # (EG - a_wall[1]);

        copyto!(v0, vG);

        for k in 2:m_wall      #   Loop for projector construction
            mul!(vG, H, v0);
            v0 .*= a_wall[k];
            vG .-= v0; normalize!(vG);

            copyto!(v0, vG);
        end                     #   Loop for projector closed
        j_wall += 1;
        #   Estimate ground state energy, <Ψ|H|Ψ>
        mul!(vG, H, v0);
        EG = dot(vG, v0);
    end                         #   Loop for iteration closed

    #   Overall multiplicative factor
    EG /= 2*Γ;

    return EG, j_wall;
end
#   ===================================================
#   Number density, <nᵢ> w.r.t. ground state
#   ===================================================
function f_num_dnsty!(L::Int, N_H::Int, v0::Vector{Float64}, n_arr::Vector{Float64})
    fill!(n_arr, 0.0)
    @inbounds for state in 0:(N_H - 1)
        s = UInt64(state)
        val = (v0[state + 1])^2

        while s != 0
            b = s & (-s)                 # isolate lowest 1-bit
            # bit (j-1) ↔ site j, as in H_EastModule
            j = trailing_zeros(b) + 1

            n_arr[j] += val

            s &= s - 1                   # clear lowest 1-bit
        end
    end
end
#   ===================================================
#   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ> w.r.t. ground state
#   ===================================================
function f_dnsty_corr!(
    L::Int, N_H::Int,
    v0::Vector{Float64},
    n_arr::Vector{Float64},
    n_corr::Vector{Float64}
)
    fill!(n_corr, 0.0)

    # <n1>
    n1 = n_arr[1]

    # Precompute masks for sites 1..L; site i ↔ bit (i-1), as in H_EastModule
    masks = ntuple(i -> UInt(1) << (i - 1), L)

    # Precompute |ψ|² once
    p = similar(v0)
    @inbounds @simd for i in eachindex(v0)
        p[i] = v0[i] * v0[i]
    end

    # Loop over distances r = 1 .. L-1
    @inbounds for r in 1:(L - 1)
        m1 = masks[1]       # bit 0 (site 1)
        mr = masks[r + 1]  # bit r (site 1+r)

        acc = 0.0
        @inbounds @simd for state in 0:(N_H - 1)
            s = UInt(state)
            acc += p[state + 1] * Float64(((s & m1) != 0) & ((s & mr) != 0))
        end

        # connected correlation
        n_corr[r] = acc - n1 * n_arr[r + 1]
    end
end
#   ===================================================
#   Magnetization in X-direction, <σˣᵢ> w.r.t. ground state
#   ===================================================
function f_sx_avg!(L::Int, N_H::Int, v0::Vector{Float64}, sx_arr::Vector{Float64})
    fill!(sx_arr, 0.0)

    #   No @simd: every iteration accumulates into the same sx_arr entries
    @inbounds for state in 0:(N_H - 1)
        v = v0[state + 1]
        s = UInt(state)

        @inbounds for i in 1:L
            #   flip spin at site i (bit i-1) via XOR
            s_flip = xor(s, UInt(1) << (i - 1))
            #   <σˣᵢ> contribution
            sx_arr[i] += v * v0[Int(s_flip) + 1]
        end
    end
end
#   ===================================================
#   Fractal dimensions
#   ===================================================
function f_Dq!(N_H::Int, lq::Int,
    vG::Vector{Float64},
    vG_sq::Vector{Float64},
    qx::Vector{Float64},
    logL_qx::Vector{Float64},
    Dq::Vector{Float64}
)
    # ----------------------------------------------------
    # 1) Compute vG_sq = vG.^2   (no allocations)
    # ----------------------------------------------------
    @inbounds @simd for i in 1:N_H
        vG_sq[i] = vG[i] * vG[i]
    end

    # ----------------------------------------------------
    # 2) Dq[q] = log( sum_i vG_sq[i]^qx[q] ) / logL_qx[q]
    # ----------------------------------------------------
    @inbounds for q in 1:lq
        qq = qx[q]
        S = 0.0

        @simd for i in 1:N_H
            S += vG_sq[i]^qq
        end

        Dq[q] = log(S) / logL_qx[q]
    end

    # ----------------------------------------------------
    # 3) Maximum intensity multifractal dimension
    # ----------------------------------------------------
    vG_sq_max = maximum(vG_sq)
    Dmax = -log(vG_sq_max) / log(N_H)

    return Dmax
end
#   ===================================================
#   Bipartite von Neumann entanglement entropy
#   ===================================================
function f_SvN!(L::Int, v::Vector{Float64}, v_to_M::Matrix{Float64})
    NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
    NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B

    copyto!(v_to_M, reshape(v, NA, NB));

    #   Singular value decomposition
    S = svd(v_to_M; full = false);
    s_vals = S.S;

    #   Compute von Neumann entanglement entropy
    SvN = 0.0;
    @inbounds for s in s_vals
        p = s^2
        if p > 0
            SvN -= p * log(p)
        end
    end

    return SvN;
end
#   ===================================================
#   von Neumann entanglement entropy for different partitions
#   ===================================================
function f_SvN_all(L::Int, v::Vector{Float64})
    L_half = div(L, 2)
    SvN_arr = zeros(L_half)

    @inbounds for j in 1:L_half
        NA = 1 << j         #   Dimension of subsystem A
        NB = 1 << (L-j)

        v_to_M = reshape(v, NA, NB)

        #   Singular value decomposition
        S = svd(v_to_M; full = false);
        s_vals = S.S;

        #   Compute von Neumann entanglement entropy
        SvN = 0.0;
        @inbounds for s in s_vals
            p = s^2
            if p > 0
                SvN -= p * log(p)
            end
        end

        SvN_arr[j] = SvN
    end

    return SvN_arr
end
#   ===================================================
#   Transform a vector from σᶻ to σˣ basis using Walsh–Hadamard transform
#   ===================================================
function trnsfrm_sz_to_sx!(N_H::Int, v::Vector{Float64})
    h = 1
    while h < N_H
        @inbounds for i in 1:(h*2):N_H # @avx for i in 1:(h*2):N_H
            for j in i:(i+h-1)
                x = v[j]
                y = v[j+h]
                v[j]   = (x + y) * INV_SQRT2
                v[j+h] = (x - y) * INV_SQRT2
            end
        end
        h *= 2
    end
    return v
end

#   ===================================================
#   Fidelity-Susceptibility of ground state for H_EBC_L + Γ V
#   ===================================================
function f_GS_chi!(s::Float64, N_H::Int, H_EBC_L::SparseMatrixCSC{Float64, Int64}, V_diag::Vector{Float64},
    EG::Float64, v0::Vector{Float64}, v1::Vector{Float64}, vk::Vector{Float64};
    α = one(real(eltype(v0))), rtol = 1e-10, maxiter = 10_000)

    fac = 1/(2 * exp(s)); Γ = exp(s)

    #   V|v0>; diagonal V
    @inbounds @simd for j in 1:N_H
        v1[j] = V_diag[j] * v0[j]
    end

    #   <v0|V|v0>
    v_mean = dot(v0, v1)

    #   v1 = <v0|V|v0>|v0> - V|v0>
    @inbounds @simd for j in 1:N_H
        v1[j] = v_mean * v0[j] - v1[j]
    end

    #   Define matrix-free operation: (H - EG*I + α|ψ><ψ|)x = y
    function A_mul!(y::Vector{Float64}, x::Vector{Float64})
        #   y = H_EBC_L * x / (2 eˢ)
        mul!(y, H_EBC_L, x, fac, zero(Float64))

        @inbounds @simd for j in eachindex(y, x, V_diag)
            y[j] += (Γ * V_diag[j] - EG) * x[j]
        end

        BLAS.axpy!(α * dot(v0, x), v0, y)

        return y
    end

    T = eltype(v0)  #   Type of the elements in v0
    #   Define linear map
    A = LinearMap{T}(
        A_mul!,
        N_H;
        ismutating = true,
        ishermitian = true,
        issymmetric = T <: Real
    )

    #   Solve A*x = b
    fill!(vk, 0.0)

    cg!(vk, A, v1;
        reltol = rtol,
        maxiter = maxiter
    )

    #   Impose orthogonality to the ground state; vk .-= v0 * dot(v0, vk)
    val = dot(v0, vk)
    @inbounds @simd for i in 1:N_H
        vk[i] -= val * v0[i]
    end

    #   Fidelity susceptibility
    χF = dot(vk, vk)

    return χF
end
#   ===================================================
end # module GSModule
