#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule, LinearAlgebra, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition
    ⋅   Exact diagonalization
    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   System parameters
s_arr = vcat(collect(-1:0.1:0), collect(0.2:0.2:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
writedlm(fname_s_vals, s_arr, '\t');
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
H_East_dense = zeros(N_H, N_H);
#   ======================================
stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s);
        @printf("s: %+5.2f\n", s);

        #   Update diagonal part of East Hamiltonian
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Exact diagonalization
        println("Exact diagonalization...")
        V_East = f_ED!(N_H, H_East_dense, H_East, E_East);
        #   Overall multiplicative factor
        E_East ./= 2*Γ;

        #   Filename
        fname_E_East = @sprintf("%s_%s_%02d_%+5.2f.dat", ftype, "e", L, s);
        fid_E_East = open(fname_E_East, "w");

        #   Printing data
        writedlm(fid_E_East, E_East, '\n'); close(fid_E_East);
    end
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
