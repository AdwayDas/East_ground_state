#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
include("/home/adway/01.Works/01.CPU/21.East/scripts/DynamicsModule.jl")
using .H_EastModule, .DynamicsModule, LinearAlgebra, Expokit, LinearMaps, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition
    ⋅   Survival probability of spin-coherent states

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   Time
tH = 2^L/sqrt(L/2+3/4);                 #   Heisenberg time
const t_arr = collect(range(0, 8*tH; length=2^10)); const lt = length(t_arr);
const dt = t_arr[2] - t_arr[1]
writedlm("time.dat", t_arr, '\n');

#   System parameters
s_arr = vcat(collect(-4:1:-2), collect(-1:0.2:-0.2), collect(-0.1:0.1:0.1), collect(0.2:0.2:1));
# vcat(collect(-1:0.1:-0.1), collect(-0.08:0.02:0.08), collect(0.1:0.1:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
writedlm(fname_s_vals, s_arr, '\t');
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H)
#   Initial state
Ψ = Vector{Float64}(undef, N_H)
#   Time evolved state
tmp = Vector{ComplexF64}(undef, N_H)
Ψt = Vector{ComplexF64}(undef, N_H)
#   Survival probability
SP_arr = Vector{Float64}(undef, lt)
#   ======================================
#   Filename
fname_SP_pol = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin-pol", L);
fid_SP_pol = open(fname_SP_pol, "w");
fname_SP_c = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin-c", L);
fid_SP_c = open(fname_SP_c, "w");

stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s); println("s: ", s);

        #   Update diagonal part of East Hamiltonian
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Survival probability
        println("Survival probability of polarized state...")
        #   Polarized state close to ground state
        Ψ .= f_spin_pol_state(L, π/3);
        
        # Lazy operator using LinearMap
        A = LinearMap(v -> -1im*(H_East*v), N_H, N_H)

        # Provide anorm to suppress warning
        anorm_est = norm(H_East, Inf)

        #   Survival probability
        f_SP_expo!(A, Ψ, dt, lt, anorm_est, tmp, Ψt, SP_arr)
        #   Store data
        writedlm(fid_SP_pol, transpose(SP_arr), '\t');
        
        #   Coherent state close to low-entangled excited state
        println("Survival probability of excited coherent state...")
        #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
        theta_arr = zeros(L); fill!(theta_arr, π/3); theta_arr[1] = 4*π/3
        Ψ .= f_spin_c_state(L, theta_arr);
        #   Survival probability
        f_SP_expo!(A, Ψ, dt, lt, anorm_est, tmp, Ψt, SP_arr)
        #   Store data
        writedlm(fid_SP_c, transpose(SP_arr), '\t');
    end
    close(fid_SP_pol);
    close(fid_SP_c);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end