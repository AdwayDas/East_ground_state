#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")

using .H_EastModule, LinearAlgebra, DelimitedFiles, Printf
#   ===================================================
#=
1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
Overlap of specific initial states with eigenstates

---Parameter descriptions---
L = Number of particles
=#
#   ===================================================
ftype = "East_L";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   Number of initial states
n_sup = 16;
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
H_East_dense = zeros(N_H, N_H)

Ψ = zeros(N_H);
olap_arr = zeros(N_H);
#   ======================================
#   Filename
fname_olap = @sprintf("%s_%s_%02d.dat", ftype, "olap", L);
fid_olap = open(fname_olap, "w");

stats = @timed begin
    println("Constructing Hamiltonian...")
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_L_off(L, N_H);
    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);

    #   Exact diagonalization
    println("Exact diagonalization...")
    V_East = f_ED!(N_H, H_East_dense, H_East, E_East);

    fname_E = @sprintf("%s_%s_%02d.dat", ftype, "E", L);
    writedlm(fname_E, E_East);
    #   --------------------------------
    #   Spin-coherent states
    #   --------------------------------
    #   Spin-coherent states with π/3 <= θ <= π/2
    theta_arr = vcat(collect(0.1:0.1:0.3), 1.0/3, 0.35, collect(0.4:0.1:2))
    theta_arr .*= π
    n_cohere = length(theta_arr)
    for n in 1:n_cohere
        θ = theta_arr[n]
        global Ψ .= f_spin_pol_state(L, θ);
        global olap_arr .= abs2.(V_East' * Ψ)
        writedlm(fid_olap, transpose(olap_arr), '\t');
    end

    #   single-particle states: e.g. |π/3>^(L-1) ⊗ |4π/3>
    theta_arr = zeros(L);
    @inbounds for j in 1:L
        fill!(theta_arr, π/3); theta_arr[j] = 4*π/3

        global Ψ .= f_spin_c_state(L, theta_arr);
        global olap_arr .= abs2.(V_East' * Ψ);
        writedlm(fid_olap, transpose(olap_arr), '\t');
    end
    
    #   Superposition states ~ |θ> + |2π - θ>
    theta_arr = range(0, π; length=n_sup)
    for n in 1:n_sup
        θ = theta_arr[n]
        #   Initial state
        global Ψ .= f_spin_pol_state(L, θ)
        global Ψ .+= f_spin_pol_state(L, 2*π - θ)
        normalize!(Ψ)

        global olap_arr .= abs2.(V_East' * Ψ);
        writedlm(fid_olap, transpose(olap_arr), '\t');
    end
    close(fid_olap)
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
