#   ===================================================
using SparseArrays, LinearAlgebra, Random, StatsBase, FFTW, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule

#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Survival probability

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
#   Gosper's hack
#   ===================================================
struct FixedPopcountIter
    L::Int
    M::Int
    limit::UInt64   # precompute 2^L
    function FixedPopcountIter(L::Int, M::Int)
        limit = UInt64(1) << L
        new(L, M, limit)
    end
end

Base.IteratorSize(::Type{FixedPopcountIter}) = Base.HasLength()
Base.length(it::FixedPopcountIter) = binomial(it.L, it.M)

@inline function Base.iterate(it::FixedPopcountIter, state::Union{Nothing, UInt64}=nothing)
    if state === nothing
        x = (UInt64(1) << it.M) - 1
        return x <= it.limit - 1 ? (x, x) : nothing
    else
        x = state
        c = x & (-x)
        r = x + c
        x_next = (((r ⊻ x) >> 2) ÷ c) | r
        return r >= it.limit ? nothing : (x_next, x_next)
    end
end

#   Return indices of Fock states in M-magnetization sector
function f_fixed_M_states(L::Int, M::Int)
    n_arr = Vector{Int}(undef, binomial(L, M))

    j = 1;
    for s in FixedPopcountIter(L, M)
        n_arr[j] = s + 1
        j += 1
    end

    return n_arr
end
#   ===================================================
#   Dynamics
#   ===================================================
#   Survival probability of a Fock state
#   ===================================================
function f_SP_Fock!(
    L::Int64, N_H::Int64, α::Int, lt::Int64,
    E_arr::Vector{Float64}, V_M::Matrix{Float64},
    t_arr::Vector{Float64}, tmp::Vector{ComplexF64}, Ψt::Vector{ComplexF64},
    SP_arr::Vector{Float64}
)
    # Precompute the coefficients V[α,n]
    vα = @view V_M[α, :]

    @inbounds for jt in 1:lt
        t = t_arr[jt]

        # fill tmp(t) without branches
        @inbounds @simd for n in 1:N_H
            tmp[n] = vα[n] * cis(-t * E_arr[n])
        end

        # Ψt = V * tmp   (BLAS)
        mul!(Ψt, V_M, tmp)

        # survival probability
        SP_arr[jt] = abs2(Ψt[α])
    end

    # equilibrium survival probability ∑ V[α,n]^4
    SP_bar = 0.0
    @inbounds @simd for n in 1:N_H
        SP_bar += vα[n]^4
    end

    return SP_bar
end
#   ===================================================
#   Survival probability of an arbitrary initial state
#   ===================================================
function f_SP!(
    L::Int, N_H::Int, Ψ::Vector{Float64}, lt::Int,
    E_arr::Vector{Float64}, V_M::Matrix{Float64},
    vα::Vector{Float64}, t_arr::Vector{Float64},
    tmp::Vector{ComplexF64}, Ψt::Vector{ComplexF64},
    SP_arr::Vector{Float64}
)

    # --- 1) Precompute overlaps   vα[n] = <E_n | Ψ>
    # BLAS: vα = V_M' * Ψ
    mul!(vα, transpose(V_M), Ψ)

    # --- 2) Survival probability over times ---
    @inbounds for jt in 1:lt
        t = t_arr[jt]

        @inbounds @simd for n in 1:N_H
            @fastmath tmp[n] = vα[n] * cis(-t * E_arr[n])
        end

        # Ψ(t) = V * tmp   (BLAS)
        mul!(Ψt, V_M, tmp)

        # | <Ψ | Ψ(t)> |^2
        SP_arr[jt] = abs2(dot(Ψt, Ψ))
    end

    # --- 3) Equilibrium survival probability ---
    SP_bar = 0.0
    @inbounds @simd for n in 1:N_H
        SP_bar = @fastmath SP_bar + vα[n]^4
    end

    return SP_bar
end
#   ===================================================
#   Normalized power-spectrum
#   ===================================================
function normalized_power_spectrum(lt::Int, x::Vector{Float64})
    X = fft(x)

    P = abs2.(X)

    # Keep positive frequencies for real input
    P = P[1:div(lt,2)+1]

    # Normalize total power to 1
    P ./ sum(P)
end
#   ===================================================
#   End of function definitions
#   ===================================================
ftype = "East_L";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   Number of initial states
n_Fock = 32; n_cohere = 8; n_sup = 32;

#   Time
tH = 2^L/sqrt(L/2+3/4);         #   Heisenberg time
const t_arr = collect(range(0, 4*tH; length=2^10)); const lt = length(t_arr);
writedlm("time.dat", t_arr, '\n');

#   Frequencies for Fourier transform of the survival probability
dt = t_arr[2] - t_arr[1]; freq = FFTW.rfftfreq(lt, 1/dt);
writedlm("freq.dat", freq, '\n');
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H)
H_East_dense = zeros(N_H, N_H)
#   Time evolved state
Ψ = Vector{Float64}(undef, N_H)
Ψt = Vector{ComplexF64}(undef, N_H)
#   Survival probability
SP_arr = Vector{Float64}(undef, lt)
#   Temporary vector d(t) = V[α,n] * exp(-i E[n] t)
tmp = Vector{ComplexF64}(undef, N_H)
#   Initial state coefficients in energy basis
vα = Vector{Float64}(undef, N_H)
#   ======================================
stats = @timed begin
    println("Constructing Hamiltonian...")
    #   Off-diagonal part of East Hamiltonian
    H_East = H_EastModule.f_H_East_EBC_L_off(L, N_H);
    #   Update diagonal part of East Hamiltonian
    H_EastModule.f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);

    #   Exact diagonalization
    println("Exact diagonalization...")
    V_East = H_EastModule.f_ED!(N_H, H_East_dense, H_East, E_East);

    #   Survival probability
    #   --------------------------------
    #   Fock states with fixed magnetization
    #   --------------------------------
    #   Randomly selecting the Fock states
    println("Calculating survival probability for Fock states...")
    #   Filename
    fname_SP = @sprintf("%s_%s_%02d.dat", ftype, "SP_Fock", L);
    fid_SP = open(fname_SP, "w");
    fname_SP_bar = @sprintf("%s_%s_%02d.dat", ftype, "SP_bar_Fock", L);
    fid_SP_bar = open(fname_SP_bar, "w");

    #   Indices of Fock states with fixed magnetization
    n_arr = f_fixed_M_states(L, div(L, 2));
    n_chosen = sample(n_arr, n_Fock; replace=false)

    for n in n_chosen
        println("Fock state index: ", n)
        global tmp, Ψt, SP_arr;
        SP_bar = f_SP_Fock!(L, N_H, n, lt, E_East, V_East, t_arr, tmp, Ψt, SP_arr);
        
        #   Store data
        writedlm(fid_SP, transpose(SP_arr), '\t');
        writedlm(fid_SP_bar, SP_bar, '\t');
    end
    close(fid_SP); close(fid_SP_bar);

    #   --------------------------------
    #   Spin-coherent states
    #   --------------------------------
    println("Spin-coherent states with π/3 <= θ <= π/2...")

    #   Filename
    fname_SP = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin_L", L);
    fid_SP = open(fname_SP, "w");
    fname_SP_bar = @sprintf("%s_%s_%02d.dat", ftype, "SP_bar_spin_L", L);
    fid_SP_bar = open(fname_SP_bar, "w");

    #   Spin-coherent states with π/3 <= θ <= π/2
    theta_arr = range(π/3, π/2; length=n_cohere)
    for n in 1:n_cohere
        println("state index: ", n)
        θ = theta_arr[n]
        #   Initial state
        global Ψ .= f_spin_pol_state(L, θ)

        global tmp, vα, Ψt, SP_arr;
        SP_bar = f_SP!(L, N_H, Ψ, lt, E_East, V_East, vα, t_arr, tmp, Ψt, SP_arr);
        
        #   Store data
        writedlm(fid_SP, transpose(SP_arr), '\t');
        writedlm(fid_SP_bar, SP_bar, '\t');
    end
    close(fid_SP); close(fid_SP_bar);

    #   Spin-coherent states with 3π/2 <= θ <= 5π/3
    println("Spin-coherent states with 3π/2 <= θ <= 5π/3...")

    #   Filename
    fname_SP = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin_R", L);
    fid_SP = open(fname_SP, "w");
    fname_SP_bar = @sprintf("%s_%s_%02d.dat", ftype, "SP_bar_spin_R", L);
    fid_SP_bar = open(fname_SP_bar, "w");

    theta_arr = range(3*π/2, 5*π/3; length=n_cohere)
    for n in 1:n_cohere
        println("state index: ", n)
        θ = theta_arr[n]
        #   Initial state
        global Ψ .= f_spin_pol_state(L, θ)

        global tmp, vα, Ψt, SP_arr;
        SP_bar = f_SP!(L, N_H, Ψ, lt, E_East, V_East, vα, t_arr, tmp, Ψt, SP_arr);
        
        #   Store data
        writedlm(fid_SP, transpose(SP_arr), '\t');
        writedlm(fid_SP_bar, SP_bar, '\t');
    end
    close(fid_SP); close(fid_SP_bar);

    #   --------------------------------
    #   Superposition of spin-coherent states
    #   --------------------------------
    println("Calculating survival probability for superposition states...")

    #   Filename
    fname_SP = @sprintf("%s_%s_%02d.dat", ftype, "SP_sup", L);
    fid_SP = open(fname_SP, "w");
    fname_SP_bar = @sprintf("%s_%s_%02d.dat", ftype, "SP_bar_sup", L);
    fid_SP_bar = open(fname_SP_bar, "w");
    fname_SP_power = @sprintf("%s_%s_%02d.dat", ftype, "SP_power_sup", L);
    fid_SP_power = open(fname_SP_power, "w");

    theta_arr = range(0, π; length=n_sup)
    Eα = zeros(n_sup)
    for n in 1:n_sup
        println("state index: ", n)
        θ = theta_arr[n]
        #   Initial state
        global Ψ .= f_spin_pol_state(L, θ)
        Ψ .+= f_spin_pol_state(L, 2*π - θ)
        normalize!(Ψ)

        #   Energy of the initial state
        mul!(vα, H_East, Ψ); Eα[n] = dot(Ψ, vα)

        global tmp, Ψt, SP_arr;
        SP_bar = f_SP!(L, N_H, Ψ, lt, E_East, V_East, vα, t_arr, tmp, Ψt, SP_arr);

        #   Power-spectrum
        P = normalized_power_spectrum(lt, SP_arr)
        
        #   Store data
        writedlm(fid_SP, transpose(SP_arr), '\t');
        writedlm(fid_SP_bar, SP_bar);
        writedlm(fid_SP_power, transpose(P), '\t');
    end
    close(fid_SP); close(fid_SP_bar); close(fid_SP_power);
    #   Energy of initial states
    fname_E_state = @sprintf("%s_%s_%02d.dat", ftype, "E_sup", L);
    writedlm(fname_E_state, Eα, '\t');
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end