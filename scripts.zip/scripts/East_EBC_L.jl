#   ===================================================
using SparseArrays, LinearAlgebra, Random, DelimitedFiles, Printf # Interpolations

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule

include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")  # loads the file with ground state functions
using .GSModule

#   ===================================================
#=
1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
eigenvalues, Dq (both Z- and X-bases), entanglement entropy

---Parameter descriptions---
L = Number of particles
=#
#   ===================================================
ftype = "East_L_full";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
H_East_dense = zeros(N_H, N_H);

v1 = Array{Float64}(undef, N_H);
v2 = Array{Float64}(undef, N_H);

#   q values for multifractal analysis
const qx = vcat(collect(-18:0.4:-5.4), collect(-5:0.1:-2), collect(-2+2e-2:2e-2:1-0.1),
 collect(1+0.1:0.1:5), collect(6:30));
const lq = length(qx);
logL_qx = log(N_H).*(1 .- qx);
fname_qx = @sprintf("%s.dat", "qx");
fid_qx = open(fname_qx, "w");
writedlm(fid_qx, qx, '\t'); close(fid_qx);

Dq_arr = Array{Float64}(undef, lq);
v_to_M = zeros(NA, NB);

Ex = collect(-2.4:0.2:2.4); lEx = length(Ex);
Ex_low = Ex .- 4e-2;
Ex_up = Ex .+ 4e-2;

Dq_M = zeros(lEx, lq);
Dmax_arr = zeros(lEx);
# P_log_arr = Vector{Float64}(undef, N_H); ax  = Vector{Float64}(undef, lq); ay  = Vector{Float64}(undef, lq);
# ax_M = zeros(lEx, lq); ay_M = zeros(lEx, lq);
state_cnt_arr = zeros(Int, lEx);
#   ======================================
stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);

    #   Exact diagonalization
    V_East = f_ED!(N_H, H_East_dense, H_East, E_East);

    #   Printing data
    fname_E_East = @sprintf("%s_%s_%02d.dat", ftype, "e", L);
    fid_E_East = open(fname_E_East, "w");
    writedlm(fid_E_East, E_East, '\n'); close(fid_E_East);

    fname_Dq = @sprintf("%s_%s_%02d.dat", ftype, "Dq", L);
    fid_Dq = open(fname_Dq, "w");
    fname_Dmax = @sprintf("%s_%s_%02d.dat", ftype, "Dmax", L);
    fid_Dmax = open(fname_Dmax, "w");
    #=
    fname_Dq_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dq_sx", L);
    fid_Dq_sx = open(fname_Dq_sx, "w");
    fname_SFD_x = @sprintf("%s_%s_%02d.dat", ftype, "SFD_x", L);
    fid_SFD_x = open(fname_SFD_x, "w");
    fname_SFD_y = @sprintf("%s_%s_%02d.dat", ftype, "SFD_y", L);
    fid_SFD_y = open(fname_SFD_y, "w");
    =#

    fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN", L);
    fid_SvN = open(fname_SvN, "w");

    @inbounds for state in 1:N_H
        E_scld = (E_East[state] + 0.5)/sqrt(L/2.0 + 0.75);
    
        copyto!(v1, @view(V_East[:, state]));

        #   Bipartite von Neumann entanglement entropy
        SvN = f_SvN!(L, v1, v_to_M);
        writedlm(fid_SvN, SvN, '\t');

        for i in 1:lEx
            if (E_scld >= Ex_low[i]) && (E_scld < Ex_up[i])
                state_cnt_arr[i] += 1;
                
                #   Fractal dimensions
                Dmax = f_Dq!(N_H, lq, v1, v2, qx, logL_qx, Dq_arr) # , P_log_arr, ax, ay)

                Dq_M[i, :] .+= Dq_arr;
                Dmax_arr[i] += Dmax;

                #=
                if state_cnt_arr[i] == 1
                    ax_M[i, :] .= ax;
                    ay_M[i, :] .= ay;
                else
                    intrp_ax = LinearInterpolation(ax, ay, extrapolation_bc=Line());
                    ay_M[i, :] .+= intrp_ax.(ax);
                end
                =#
                break
            end
        end

        #=
        #   Transform from σᶻ to σˣ basis
        trnsfrm_sz_to_sx!(N_H, v1);

        #   Fractal dimensions in σˣ basis
        Dmax_sx = f_Dq!(N_H, lq, v1, v2, qx, logL_qx, Dq_arr)
        writedlm(fid_Dq_sx, Dq_arr', '\t');
        =#
    end
    close(fid_SvN);

    #   Average over states in each energy window
    for i in 1:lEx
        cnt = state_cnt_arr[i];
        if cnt > 0
            Dq_M[i, :] ./= cnt;
            Dmax_arr[i] /= cnt;
            # ay_M[i, :] ./= cnt;
        end

        writedlm(fid_Dq, Dq_M[i, :]', '\t');
        writedlm(fid_Dmax, Dmax_arr[i], '\t');
        
        # (fid_SFD_x, ax_M[i, :]', '\t');
        # writedlm(fid_SFD_y, ay_M[i, :]', '\t');
    end
    close(fid_Dq);
    close(fid_Dmax);
    
    # close(fid_SFD_x); close(fid_SFD_y);
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
