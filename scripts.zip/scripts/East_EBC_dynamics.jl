#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
include("/home/adway/01.Works/01.CPU/21.East/scripts/DynamicsModule.jl")
using .H_EastModule, .DynamicsModule, LinearAlgebra, Expokit, LinearMaps, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition
    ⋅   Dynamics of spin-coherent states

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   Time
tH = 2^L/sqrt(L/2+3/4);                 #   Heisenberg time
const t_arr = collect(range(0, 8*tH; length=2^10)); const lt = length(t_arr);
const dt = t_arr[2] - t_arr[1]
writedlm("time.dat", t_arr, '\n');

#   System parameters
s_arr = vcat(collect(-4:1:-2), collect(-1:0.2:-0.2), collect(-0.1:0.1:0.1), collect(0.2:0.2:1));
# vcat(collect(-1:0.1:-0.1), collect(-0.08:0.02:0.08), collect(0.1:0.1:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
writedlm(fname_s_vals, s_arr, '\t');

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H)
#   Initial state
Ψ = Vector{Float64}(undef, N_H)
#   Time evolved state
tmp = Vector{ComplexF64}(undef, N_H)
Ψt = Vector{ComplexF64}(undef, N_H)
#   Survival probability
SP_arr = Vector{Float64}(undef, lt)
n_M = Matrix{Float64}(undef, lt, L)
n_avg = Vector{Float64}(undef, lt)
sx_M = Matrix{ComplexF64}(undef, lt, L)
sx_avg = Vector{ComplexF64}(undef, lt)
Svn_avg = Vector{Float64}(undef, lt)
v_to_M = Matrix{ComplexF64}(undef, NA, NB);
#   ======================================
#   Filename
fname_SP_pol = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin-pol", L);
fid_SP_pol = open(fname_SP_pol, "w");
fname_n_pol = @sprintf("%s_%s_%02d.dat", ftype, "n_spin-pol", L);
fid_n_pol = open(fname_n_pol, "w");
fname_sx_real_pol = @sprintf("%s_%s_%02d.dat", ftype, "sx_real_spin-pol", L);
fid_sx_real_pol = open(fname_sx_real_pol, "w");
fname_sx_imag_pol = @sprintf("%s_%s_%02d.dat", ftype, "sx_imag_spin-pol", L);
fid_sx_imag_pol = open(fname_sx_imag_pol, "w");
fname_SvN_pol = @sprintf("%s_%s_%02d.dat", ftype, "SvN_spin-pol", L);
fid_SvN_pol = open(fname_SvN_pol, "w");

fname_SP_c = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin-c", L);
fid_SP_c = open(fname_SP_c, "w");
fname_n_c = @sprintf("%s_%s_%02d.dat", ftype, "n_spin-c", L);
fid_n_c = open(fname_n_c, "w");
fname_sx_real_c = @sprintf("%s_%s_%02d.dat", ftype, "sx_real_spin-c", L);
fid_sx_real_c = open(fname_sx_real_c, "w");
fname_sx_imag_c = @sprintf("%s_%s_%02d.dat", ftype, "sx_imag_spin-c", L);
fid_sx_imag_c = open(fname_sx_imag_c, "w");
fname_SvN_c = @sprintf("%s_%s_%02d.dat", ftype, "SvN_spin-c", L);
fid_SvN_c = open(fname_SvN_c, "w");

stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s); println("s: ", s);

        #   Update diagonal part of East Hamiltonian
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Survival probability
        println("Dynamics of polarized state...")
        #   Polarized state close to ground state
        Ψ .= f_spin_pol_state(L, π/3);
        
        # Lazy operator using LinearMap
        A = LinearMap(v -> -1im*(H_East*v), N_H, N_H)

        # Provide anorm to suppress warning
        anorm_est = norm(H_East, Inf)

        #   Dynamics
        f_dynamics_expo!(L, N_H, A, Ψ,
                dt, lt, anorm_est, tmp, Ψt,
                SP_arr, n_M, sx_M, Svn_avg, v_to_M);
        #   Average over sites
        n_avg .= sum(n_M, dims=2); sx_avg .= sum(sx_M, dims=2);
        n_avg ./= L; sx_avg ./= L;
        #   Store data
        writedlm(fid_SP_pol, transpose(SP_arr), '\t');
        writedlm(fid_n_pol, transpose(n_avg), '\t');
        writedlm(fid_sx_real_pol, transpose(real.(sx_avg)), '\t');
        writedlm(fid_sx_imag_pol, transpose(imag.(sx_avg)), '\t');
        writedlm(fid_SvN_pol, transpose(Svn_avg), '\t');
        
        #   Coherent state close to low-entangled excited state
        println("Dynamics of excited coherent state...")
        #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
        theta_arr = zeros(L); fill!(theta_arr, π/3); theta_arr[1] = 4*π/3
        Ψ .= f_spin_c_state(L, theta_arr);
        #   Dynamics
        f_dynamics_expo!(L, N_H, A, Ψ,
                dt, lt, anorm_est, tmp, Ψt,
                SP_arr, n_M, sx_M, Svn_avg, v_to_M);
        #   Average over sites
        n_avg .= sum(n_M, dims=2); sx_avg .= sum(sx_M, dims=2);
        n_avg ./= L; sx_avg ./= L;
        #   Store data
        writedlm(fid_SP_c, transpose(SP_arr), '\t');
        writedlm(fid_n_c, transpose(n_avg), '\t');
        writedlm(fid_sx_real_c, transpose(real.(sx_avg)), '\t');
        writedlm(fid_sx_imag_c, transpose(imag.(sx_avg)), '\t');
        writedlm(fid_SvN_c, transpose(Svn_avg), '\t');
    end
    close(fid_SP_pol); close(fid_SP_c);
    close(fid_n_pol); close(fid_n_c);
    close(fid_sx_real_pol); close(fid_sx_real_c);
    close(fid_sx_imag_pol); close(fid_sx_imag_c);
    close(fid_SvN_pol); close(fid_SvN_c);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end