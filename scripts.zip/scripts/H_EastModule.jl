module H_EastModule

#   Hamiltonian of East model with East boundary conditions
#   Bit convention: bit (k-1) of a basis state ↔ site k; bit = 1 ↔ spin up
export f_H_East_EBC_off, f_H_East_EBC_diag, f_H_East_EBC_update_diag!, f_H_East_PBC_L,
       f_H_East_EBC_L_off, f_H_East_EBC_L_update_diag!, f_H_East_EBC_L_perturb!, f_ED!, f_ED_E_only!,
       f_spin_c_state, f_spin_pol_state, f_pi_pulse_Y,
       f_m_Lanczos_v0!

using SparseArrays, LinearAlgebra

#   ===================================================
#   Off-diagonal terms of East Hamiltonian with East boundary conditions
#   ===================================================
function f_H_East_EBC_off(L::Int, N_H::Int)
    # Precompute XOR masks for flips at bit positions 1..L
    flips = Vector{UInt64}(undef, L)
    @inbounds for k = 1:L
        flips[k] = UInt64(1) << k
    end

    # Estimate nnz (rough): each "10" produces 2 entries, boundary maybe 2 per state
    est = max(16, N_H * (L >> 1) * 2 + N_H)  # ensure >= 1

    I = Vector{Int}(undef, est)
    J = Vector{Int}(undef, est)
    V = Vector{Float64}(undef, est)
    idx = 1

    fullmask = (UInt64(1) << (L - 1)) - 1

    @inbounds for state in 0:(N_H - 1)
        s = UInt64(state)
        i = state + 1

        # interior "10" pairs on bits 0..L-2
        mask10 = (s & ~(s >> 1)) & fullmask

        while mask10 != 0
            b = mask10 & (-mask10)
            n = Base.trailing_zeros(b)         # index n of the "10" at bit n
            new_state = s ⊻ flips[n+1]         # correct bit flip via XOR
            j = Int(new_state) + 1

            # ensure capacity; if estimate was too small, grow by doubling
            if idx + 1 > length(I)
                newcap = max(length(I) * 2, 16)
                resize!(I, newcap); resize!(J, newcap); resize!(V, newcap)
            end

            I[idx] = i;  J[idx] = j;  V[idx] = -1.0; idx += 1
            I[idx] = j;  J[idx] = i;  V[idx] = -1.0; idx += 1

            mask10 &= mask10 - 1
        end

        # east boundary σˣ₁ (flip bit 0)
        if (s & 0x1) == 0
            new_state = s ⊻ 0x1
            j = Int(new_state) + 1

            # ensure capacity; if estimate was too small, grow by doubling
            if idx + 1 > length(I)
                newcap = max(length(I) * 2, 16)
                resize!(I, newcap); resize!(J, newcap); resize!(V, newcap)
            end

            I[idx] = i;  J[idx] = j;  V[idx] = -1.0; idx += 1
            I[idx] = j;  J[idx] = i;  V[idx] = -1.0; idx += 1
        end
    end

    nnz = idx - 1
    if nnz == 0
        return spzeros(N_H, N_H)
    end

    # Truncate to actual filled length to avoid passing garbage to sparse
    resize!(I, nnz); resize!(J, nnz); resize!(V, nnz)

    return sparse(I, J, V, N_H, N_H)
end
#   ===================================================
#   Diagonal terms of East Hamiltonian with East boundary conditions
#   ===================================================
function f_H_East_EBC_diag(L::Int, Γ::Float64)
    N_H = 1 << L       #   Hilbert space dimension

    #   |00...01>
    mask_L = UInt(1) << (L-1)
    #   |11...10>
    mask = mask_L - 1

    E_East = zeros(N_H)
    @inbounds for state in 0:(N_H-1)
        s = UInt(state)

        #   Number of up spins among sites 1..L-1
        up_count = count_ones(s & mask)

        #   Each up spin contributes Γ
        E_East[state + 1] += Γ * up_count

        #   Boundary L contribution: Γ n_L - n_L
        if s & mask_L != 0
            #   if Lth spin == 1
            E_East[state + 1] += (Γ-1)
        end
    end

    #   Apply global Γ * I
    E_East .+= Γ

    return E_East
end
#   ===================================================
#   Update diagonal terms of East Hamiltonian with East boundary conditions
#   ===================================================
function f_H_East_EBC_update_diag!(L::Int, N_H::Int, Γ::Float64, E_East::Vector{Float64}, H_East::SparseMatrixCSC{Float64, Int64})

    #   |00...01>
    mask_L = UInt(1) << (L-1)
    #   |11...10>
    mask = mask_L - 1

    fill!(E_East, 0.0)
    @inbounds for state in 0:(N_H-1)
        s = UInt(state)

        #   Number of up spins among sites 1..L-1
        up_count = count_ones(s & mask)

        #   Each up spin contributes Γ
        E_East[state + 1] += Γ * up_count

        #   Boundary L contribution: Γ n_L - n_L
        if s & mask_L != 0
            #   if Lth spin == 1
            E_East[state + 1] += (Γ-1)
        end
    end

    #   Apply global Γ * I
    E_East .+= Γ

    #   No @simd: setindex! on a sparse matrix may insert entries
    @inbounds for i in 1:N_H
        H_East[i,i] = E_East[i]
    end
end
#   ===================================================
#   Off-diagonal terms of East Hamiltonian with s → -∞ and East boundary conditions
#   ===================================================
#   Identical to f_H_East_EBC_off; kept as a separate name for existing scripts
f_H_East_EBC_L_off(L::Int, N_H::Int) = f_H_East_EBC_off(L, N_H)
#   ===================================================
#   Diagonal terms of East Hamiltonian with s → -∞ and East boundary conditions
#   ===================================================
function f_H_East_EBC_L_update_diag!(L::Int, N_H::Int, E_East::Vector{Float64}, H_East::SparseMatrixCSC{Float64, Int64})

    fill!(E_East, 0.0)
    #   |00...01>
    mask_L = UInt(1) << (L-1)

    @inbounds for state in 0:(N_H-1)
        s = UInt(state)

        # Boundary L contribution if Lth spin is up
        if s & mask_L != 0
            E_East[state + 1] -= 1.0
        end
    end

    #   No @simd: setindex! on a sparse matrix may insert entries
    @inbounds for i in 1:N_H
        H_East[i, i] = E_East[i]
    end
end
#   ===================================================
#   Finite s perturbation to East Hamiltonian with s → -∞ and East boundary conditions
#   (I + N)/(2 eˢ)
#   ===================================================
function f_H_East_EBC_L_perturb!(L::Int, s::Float64, E_East::Vector{Float64})
    N_H = 1 << L       #   Hilbert space dimension
    fill!(E_East, 0.0)

    #   |11...1>
    mask = (UInt(1) << L) - 1

    val = 1/(2 * exp(s))

    #   N/(2 eˢ)
    @inbounds for state in 0:(N_H-1)
        #   (named st, not s, so the argument s is not overwritten)
        st = UInt(state)

        #   Number of up spins
        up_count = count_ones(st & mask)

        #   Each up spin contributes val
        E_East[state + 1] += up_count * val
    end

    #   Apply global I/(2 eˢ)
    E_East .+= val

    return E_East
end
#   ===================================================
#   East Hamiltonian with s → -∞ and periodic boundary condition
#   ===================================================
function f_H_East_PBC_L(L::Int, N_H::Int)
    # Expect N_H == 1 << L typically; but keep general.
    # Precompute per-bond masks for bonds between (n-1, n) where n = 1:(L-1)
    # For each bond index n (1..L-1):
    #   checkmask[n]  = (1 << (n-1)) | (1 << n)
    #   success condition: (state & checkmask[n]) == (1 << (n-1))  # bit(n-1)==1 && bit(n)==0
    #   flipmask[n]   = (1 << n)   # flip bit n (0->1)
    checkmask = Vector{UInt64}(undef, max(0, L-1))
    flipmask  = Vector{UInt64}(undef, max(0, L-1))

    @inbounds for n in 1:(L-1)
        checkmask[n] = (UInt64(1) << (n-1)) | (UInt64(1) << n)
        flipmask[n]  = (UInt64(1) << n)
    end

    # PBC bond between (L-1, 0):
    # condition: bit(L-1) == 1 && bit(0) == 0  => (state & checkmask_pbc) == (1 << (L-1))
    checkmask_pbc = (UInt64(1) << (L-1)) | UInt64(1)
    flipmask_pbc  = UInt64(1)  # flip bit 0

    # Estimate nnz (each transition adds two entries)
    est = 2 * N_H * div(L, 2)
    I = Vector{Int}(undef, 0); J = Vector{Int}(undef, 0); V = Vector{Float64}(undef, 0)
    sizehint!(I, est); sizehint!(J, est); sizehint!(V, est)

    @inbounds for s in UInt64(0):(UInt64(N_H - 1))
        i = Int(s + 1)

        # internal bonds n = 1:(L-1)
        @inbounds for n in 1:(L-1)
            if (s & checkmask[n]) == (UInt64(1) << (n-1))
                j = Int(s ⊻ flipmask[n]) + 1  # j_state index -> +1 for 1-based
                push!(I, i); push!(J, j); push!(V, -1.0)
                push!(I, j); push!(J, i); push!(V, -1.0)
            end
        end

        # periodic bond (L-1,0)
        if (s & checkmask_pbc) == (UInt64(1) << (L-1))
            j = Int(s ⊻ flipmask_pbc) + 1
            push!(I, i); push!(J, j); push!(V, -1.0)
            push!(I, j); push!(J, i); push!(V, -1.0)
        end
    end

    return sparse(I, J, V, N_H, N_H)
end
#   ===================================================
#   Exact diagonalization
#   ===================================================
function f_ED!(N_H::Int, H_dense::Matrix{Float64},
    H::SparseMatrixCSC{Float64, Int},
    E_arr::Vector{Float64})

    fill!(H_dense, 0.0)

    # --- Efficient sparse → dense copy ---
    @inbounds for col in 1:N_H
        for k in H.colptr[col]:(H.colptr[col+1]-1)
            row = H.rowval[k]
            H_dense[row, col] = H.nzval[k]
        end
    end

    # --- Dense eigenvalue solver ---
    eig_strc = eigen!(Symmetric(H_dense))
    @inbounds copyto!(E_arr, eig_strc.values)

    #   Eigenvectors
    return eig_strc.vectors
end
#   ===================================================
#   Exact diagonalization (eigenvalues only)
#   ===================================================
function f_ED_E_only!(N_H::Int, H_dense::Matrix{Float64},
    H::SparseMatrixCSC{Float64, Int},
    E_arr::Vector{Float64})

    fill!(H_dense, 0.0)

    # --- Efficient sparse → dense copy ---
    @inbounds for col in 1:N_H
        for k in H.colptr[col]:(H.colptr[col+1]-1)
            row = H.rowval[k]
            H_dense[row, col] = H.nzval[k]
        end
    end

    # --- Dense eigenvalue solver ---
    E_arr .= eigvals!(Symmetric(H_dense))

    return nothing
end
#   ===================================================
#   Spin-coherent state; θ[i] acts on site i (bit i-1)
#   ===================================================
function f_spin_c_state(L::Int, θ::Vector{Float64})
    vec = [1.0]   # start as scalar 1
    @inbounds for i in 1:L
        site = [sin(θ[i]/2); cos(θ[i]/2)];
        #   kron's last factor is the least significant bit, so prepend
        vec = kron(site, vec)
    end
    return vec
end
#   ===================================================
#   Polarized spin-coherent state
#   ===================================================
function f_spin_pol_state(L::Int, θ::Float64)
    vec = [1.0]   # start as scalar 1
    site = [sin(θ/2); cos(θ/2)];
    @inbounds for i in 1:L
        vec = kron(site, vec)
    end
    return vec
end
#   ===================================================
#   π-pulse on a state around Y-axis on jth site
#   ===================================================
function f_pi_pulse_Y(L::Int, j::Int, v::Vector{Float64})
    #   Output vector
    v1 = similar(v)
    #   Hilbert space dimension
    N_H = 1 << L

    @inbounds for n in 0:(N_H - 1)
        s = UInt64(n)
        #   Index after flipping jth bit
        n1 = n ⊻ (1 << (j-1))

        #   Check if jth bit of s is up or down
        if (s >> (j-1)) & 0x1 == 1
            # jth spin is up; Ry(π)|↑⟩ = |↓⟩
            v1[n1+1] = v[n+1]
        else
            # jth spin is down; Ry(π)|↓⟩ = -|↑⟩
            v1[n1+1] = -v[n+1]
        end
    end
    
    return v1
end
#   ===================================================
#   m-step Lanczos reduction from a given vector
#   ===================================================
function f_m_Lanczos_v0!(
    N::Int, m::Int,
    H::SparseMatrixCSC{Float64,Int},
    v0::Vector{Float64}
)
    #   Tolerance value for stopping Lanczos iteration (same as DynamicsModule)
    tol = sqrt(eps(Float64))
    #   Work vectors
    v1 = Vector{Float64}(undef, N)
    vk = similar(v1)
    pot = Vector{Float64}(undef, m)
    hop = Vector{Float64}(undef, m)
    #   Lanczos basis
    Qm = Matrix{Float64}(undef, N, m)

    #   Initial vector (normalized in place)
    v0 ./= norm(v0)
    @views copyto!(Qm[:,1], v0)

    # vk = H * q1
    mul!(vk, H, v0)

    # a1
    ak = dot(v0, vk)
    pot[1] = ak

    # vk -= a1 * q1
    @inbounds @. vk -= ak * v0

    # b1
    bk = norm(vk)

    # effective Lanczos dimension
    m_eff = 1

    if bk < tol
        hop .= 0.0
    else
        hop[1] = bk
        copyto!(v1, v0)   # q_{j-1} = q1

        # --- Lanczos loop ---
        for j in 2:m
            # q_j = vk / b_{j-1}
            @inbounds @. v0 = vk / bk
            @views copyto!(Qm[:, j], v0)

            # vk = H * q_j
            mul!(vk, H, v0)

            # vk -= b_{j-1} * q_{j-1}
            @inbounds @. vk -= bk * v1

            # a_j
            ak = dot(v0, vk)
            pot[j] = ak

            # vk -= a_j * q_j
            @inbounds @. vk -= ak * v0

            # --- full reorthogonalization ---
            for iQ in 1:(j-1)
                @views q = Qm[:, iQ]
                c = dot(q, vk)
                LinearAlgebra.BLAS.axpy!(-c, q, vk)
            end

            # b_j
            bk = norm(vk)
            m_eff = j

            if bk < tol
                break
            end

            hop[j] = bk
            copyto!(v1, v0)
        end
    end

    # --- build Tm (only up to m_eff) ---
    # A zero-padded m × m matrix would add spurious zero Ritz values
    Tm = SymTridiagonal(pot[1:m_eff], hop[1:(m_eff-1)])

    # --- eigen-decomposition ---
    egn = eigen!(Tm)

    return m_eff, egn.values, egn.vectors
end
#   ===================================================
end # module H_EastModule
#   ===================================================