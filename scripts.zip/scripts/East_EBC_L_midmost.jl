#   ===================================================
using SparseArrays, LinearAlgebra, Random, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")  # loads the file with ground state functions
using .GSModule
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Middlemost state properties

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
#   Define functions
#   ===================================================
#   Middlemost state using wall-Chebyshev method (assuming DOS symmetric about zero energy)
#   ===================================================
function f_Wall_mid!(E_low::Float64, E_up::Float64, E_tol::Float64, m_wall::Int64, n_wall::Int64,
    H::SparseMatrixCSC{Float64, Int64}, a_wall_scld::Array{Float64}, a_wall::Array{Float64}, v0::Array{Float64}, v1::Array{Float64}, vG::Array{Float64})
    #   Initial vector
    randn!(v0); normalize!(v0);

    #   Initial estimate of middlemost state energy, <Ψ|H|Ψ>
    mul!(v1, H, v0); mul!(vG, H, v1);
    EG = dot(vG, v0);

    #   Loop for iteration
    j_wall = 0; E0 = 0.0;
    fac = max(E_up^2, E_low^2)/2; # E_low = 0 for H²

    while abs(E0 - EG) > E_tol && j_wall < n_wall
        E0 = EG;
        #   Wall-Chebyshev nodes
        copyto!(a_wall, a_wall_scld);
        a_wall .*= fac; a_wall .+= EG;

        v0 .*= a_wall[1];
        vG .-= v0;
        normalize!(vG); # (EG - a_wall[1]);

        copyto!(v0, vG);

        for k in 2:m_wall      #   Loop for projector construction
            mul!(v1, H, v0); mul!(vG, H, v1);
            v0 .*= a_wall[k];
            vG .-= v0; normalize!(vG);

            copyto!(v0, vG);
        end                     #   Loop for projector closed
        j_wall += 1;
        #   Estimate ground state energy, <Ψ|H|Ψ>
        mul!(v1, H, v0); mul!(vG, H, v1);
        EG = dot(vG, v0);
    end                         #   Loop for iteration closed

    #   Ground state of H^2 = middlemost state of H provided DOS symmetric about zero
    #   Actual energy
    mul!(vG, H, v0); EG = dot(vG, v0);

    return EG, j_wall;
end
#   ===================================================
#   End of function definitions
#   ===================================================
ftype = "East_L_mid";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   q values for Dq analysis
const qx = vcat(collect(0:0.1:1-0.1), collect(1+0.1:0.1:5), collect(6:30));
const lq = length(qx);
logL_qx = log(N_H).*(1 .- qx);
fname_qx = @sprintf("%s.dat", "qx");
fid_qx = open(fname_qx, "w");
writedlm(fid_qx, qx, '\t'); close(fid_qx);

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B
#   ===================================================
#   Internal parameters
const m = 16;   #   Number of Lanczos steps
const Nv = 8;   #   Number of repetitions for m-step Lanczos
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   Number of points in the energy axis
const lEx = 64;
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);

#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);

a_wall = Array{Float64}(undef, m_wall);
n_arr = Array{Float64}(undef, L);
n_corr = Array{Float64}(undef, L-1);
Dq_arr = Array{Float64}(undef, lq);
v_to_M = zeros(NA, NB);

E_mom_arr = Array{Float64}(undef, 4);
#   ======================================
#   Filenames
#   ======================================
#   Energy
fname_E = @sprintf("%s_%s_%02d.dat", ftype, "E", L);
fid_E = open(fname_E, "w");

#   Number density
fname_n_dnsty = @sprintf("%s_%s_%02d.dat", ftype, "n_dnsty", L);
fid_n_dnsty = open(fname_n_dnsty, "w");

#   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ>
fname_n_nr = @sprintf("%s_%s_%02d.dat", ftype, "n_nr", L);
fid_n_nr = open(fname_n_nr, "w");

#   Magnetization in X-direction, <σˣᵢ>
fname_sx = @sprintf("%s_%s_%02d.dat", ftype, "sx", L);
fid_sx = open(fname_sx, "w");

#   Fractal dimensions
fname_Dq = @sprintf("%s_%s_%02d.dat", ftype, "Dq", L);
fname_Dmax = @sprintf("%s_%s_%02d.dat", ftype, "Dmax", L);
fid_Dq = open(fname_Dq, "w");
fid_Dmax = open(fname_Dmax, "w");

#   Fractal dimensions in σˣ basis
fname_Dq_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dq_sx", L);
fname_Dmax_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dmax_sx", L);
fid_Dq_sx = open(fname_Dq_sx, "w");
fid_Dmax_sx = open(fname_Dmax_sx, "w");

#   von Neumann entanglement entropy
fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN", L);
fid_SvN = open(fname_SvN, "w");
#   ======================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = f_wall_node(m_wall);
    
    #   Off-diagonal part of East Hamiltonian
    H_East = H_EastModule.f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    E_East = zeros(Float64, N_H);
    H_EastModule.f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);
    #   Offset by 1/2 to center around zero energy
    H_East[1:N_H+1:end] .+= 0.5;

    #   Estimate energy bounds from m-step Lanczos reduction
    global v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm;
    E_low, E_up = f_E_bound_Lanczos!(N_H, m, Nv, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm);
        
    #   Middlemost energy using wall-Chebyshev method
    global a_wall;
    EG, j_wall = f_Wall_mid!(E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1, vk);
    EG -= 0.5   #   Accounting for offset
    writedlm(fid_E, EG, '\t'); close(fid_E);

    #   Number density, <nᵢ>
    global n_arr;
    f_num_dnsty!(L, N_H, v0, n_arr);
    writedlm(fid_n_dnsty, n_arr', '\t'); close(fid_n_dnsty);

    #   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ>
    global n_corr;
    f_dnsty_corr!(L, N_H, v0, n_arr, n_corr);
    writedlm(fid_n_nr, n_corr', '\t'); close(fid_n_nr);

    #   Magnetization in X-direction, <σˣᵢ>
    f_sx_avg!(L, N_H, v0, n_arr);
    writedlm(fid_sx, n_arr', '\t'); close(fid_sx);
    #   Fractal dimensions
    Dmax = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq, Dq_arr', '\t'); close(fid_Dq);
    writedlm(fid_Dmax, Dmax, '\t'); close(fid_Dmax);

    #   Bipartite von Neumann entanglement entropy
    SvN = f_SvN!(L, v0, v_to_M);
    writedlm(fid_SvN, SvN, '\t'); close(fid_SvN);
        
    #   Represent the ground state in σˣ basis
    trnsfrm_sz_to_sx!(N_H, v0);

    #   Fractal dimensions in σˣ basis
    Dmax_sx = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq_sx, Dq_arr', '\t'); close(fid_Dq_sx);
    writedlm(fid_Dmax_sx, Dmax_sx, '\t'); close(fid_Dmax_sx);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end