module DOSModule

#   Ground state observables
export f_DOS_Lanczos!, f_E_mom! # , f_Jack, f_KPM!, f_DOS_KPM

using SparseArrays, LinearAlgebra, Random, Polynomials

#   ===================================================
#   Estimate lower and upper energy bound from m-step Lanczos reduction
#   ===================================================
function f_E_bound_Lanczos!(N::Int, m::Int, 
    Nv::Int,                # number of initial random vectors
    H::SparseMatrixCSC{Float64,Int},
    v0::Vector{Float64}, v1::Vector{Float64}, vk::Vector{Float64},
    Qm::Matrix{Float64},    #   orthonormal basis in m-dim Lanczos space
    pot::Vector{Float64},   #   diagonal Lanczos coefficients
    hop::Vector{Float64},   #   off-diagonal Lanczos coefficients
    Tm::SymTridiagonal{Float64,Vector{Float64}}, #  Tridiagonal matrix from Lanczos reduction
    E_Tm::Vector{Float64}, V_Tm::Matrix{Float64}
)
    E_up_arr  = similar(E_Tm, Nv)
    E_low_arr = similar(E_Tm, Nv)

    diagT = Tm.dv        # diagonal
    offT  = Tm.ev        # off-diagonal (length m-1)

    @inbounds for jv in 1:Nv

        # --- initial random vector ---
        randn!(v0)
        normalize!(v0)
        @views copyto!(Qm[:,1], v0)

        # vk = H * v0
        mul!(vk, H, v0)

        ak = dot(v0, vk)
        pot[1] = ak

        @inbounds @simd for i in 1:N
            vk[i] -= ak * v0[i]
        end

        bk = norm(vk)
        hop[1] = bk

        copyto!(v1, v0)   # store q_{j-1}

        # --- Lanczos loop ---
        for j in 2:m
            # q_j = vk / b_{j-1}
            @inbounds @simd for i in 1:N
                v0[i] = vk[i] / bk
            end
            @views copyto!(Qm[:, j], v0)

            # vk = H * q_j
            mul!(vk, H, v0)

            # vk -= b_{j-1} * q_{j-1}
            @inbounds @simd for i in 1:N
                vk[i] -= bk * v1[i]
            end

            # a_j = q_j ⋅ vk
            ak = dot(v0, vk)
            pot[j] = ak

            # vk -= a_j * q_j
            @inbounds @simd for i in 1:N
                vk[i] -= ak * v0[i]
            end

            # full reorthogonalization
            @inbounds for iQ in 1:(j-1)
                @views q = Qm[:, iQ]
                c = dot(q, vk)
                @inbounds @simd for k in 1:N
                    vk[k] -= c * q[k]
                end
            end

            # next b_j
            bk = norm(vk)
            hop[j] = bk

            # shift q_{j-1} ← q_j
            copyto!(v1, v0)
        end

        # --- build Tm in-place ---
        @inbounds for i in 1:m
            diagT[i] = pot[i]
        end
        @inbounds for i in 1:(m-1)
            offT[i] = hop[i]
        end

        # eigen-decomposition of Tm
        eig = eigen!(Tm)
        @inbounds copyto!(E_Tm, eig.values)
        @inbounds copyto!(V_Tm, eig.vectors)

        # upper / lower bounds
        E_up_arr[jv]  = E_Tm[m] + hop[m] * abs(V_Tm[m,m])
        E_low_arr[jv] = E_Tm[1] - hop[m] * abs(V_Tm[m,1])
    end

    return minimum(E_low_arr), maximum(E_up_arr)
end
#   ===================================================
#   Gibbs damping coefficients from Jackson kernel
#   ===================================================
function f_Jack(N_mom::Int64, N::Int64)
    g_Jack = collect(0.0:N_mom-1);
    g_Jack .= (N_mom + 1 .- g_Jack).*cos.((pi/(N_mom+1)).*g_Jack) .+ cot(pi/(N+1)).*sin.((pi/(N_mom+1)).*g_Jack);
    g_Jack ./= (N_mom+1);

    return g_Jack;
end
#   ===================================================
#   Kernel polynomial method
#   ===================================================
function f_KPM!(N::Int, Nm::Int, N_mom::Int, N_vec::Int, M::SparseMatrixCSC{Float64, Int},
                   v0::Vector{Float64}, v1::Vector{Float64}, v2::Vector{Float64}, vk::Vector{Float64},
                   g_Jack::Vector{Float64}, mu_arr::Vector{Float64}, mu_avg::Vector{Float64})
    fill!(mu_avg, 0.0)

    @inbounds for jv in 1:N_vec
        # Random initial vector
        randn!(v0)
        fill!(mu_arr, 0.0)

        # μ0
        mu_arr[1] = dot(v0, v0)

        # μ1
        mul!(v2, M, v0)
        mu_arr[2] = dot(v2, v0)

        # initial v1 = v0
        copyto!(v1, v0)

        # --- alias the vectors through variables for rotation ---
        a = v0
        b = v1
        c = v2
        d = vk

        # Loop jn = 3 : Nm
        @inbounds @simd for jn in 3:Nm
            mul!(d, M, c)
            d .*= 2.0
            d .-= b
            mu_arr[jn] = dot(d, a)

            # rotate: (b,c,d) = (c,d,b)
            tmp = b
            b = c
            c = d
            d = tmp
        end

        # Loop jn = Nm+1 : 2Nm-1
        @inbounds for jn in (Nm + 1):(2Nm - 1)
            mul!(d, M, c)
            d .*= 2.0
            d .-= b
            mu_arr[jn] = dot(d, a)

            # symmetry
            mu_arr[2*jn - 2] = 2.0 * dot(d, c) - mu_arr[2]
            mu_arr[2*jn - 1] = 2.0 * dot(d, d) - mu_arr[1]

            tmp = b
            b = c
            c = d
            d = tmp
        end

        # jn = 2Nm
        mul!(d, M, c)
        d .*= 2.0
        d .-= b

        mu_arr[N_mom - 2] = 2.0 * dot(d, c) - mu_arr[2]
        mu_arr[N_mom - 1] = 2.0 * dot(d, d) - mu_arr[1]

        tmp = b
        b = c
        c = d
        d = tmp

        # final μ_(N_mom)
        mul!(d, M, c)
        d .*= 2.0
        d .-= b
        mu_arr[N_mom] = 2.0 * dot(d, c) - mu_arr[2]

        # accumulate
        mu_avg .+= mu_arr
    end

    # normalization
    mu_avg ./= N_vec
    mu_avg .*= (2.0 / (π * N))
    mu_avg[1] /= 2.0

    # Jackson kernel
    mu_avg .*= g_Jack

    return nothing
end
#   ===================================================
#   DOS from moments
#   ===================================================
function f_DOS_KPM(N_mom::Int64, mu_avg::Vector{Float64}, E_scl::Float64, E_shft::Float64)
#   Sum of Chebyshev polynomials
p = ChebyshevT(mu_avg);

dEx = 4e-2; Ex = collect(-0.99:dEx:0.99);
Ey = p.(Ex)./sqrt.(1 .- Ex.^2);

#   Reverting to original energy units
# E_scl = (E_up - E_low)/(2 - 1/N); E_shft = (E_up + E_low)/2;
Ex .*= E_scl; Ex .+= E_shft;
Ey ./= E_scl;
    
return Ex, Ey;
end
#   ===================================================
#   DOS from m-step Lanczos reduction
#   ===================================================
function f_DOS_Lanczos!(N::Int, m::Int, Nv::Int, lEx::Int,
    M::SparseMatrixCSC{Float64,Int}, v0::Vector{Float64}, v1::Vector{Float64},
    vk::Vector{Float64}, Qm::Matrix{Float64}, pot::Vector{Float64},
    hop::Vector{Float64}, Tm::SymTridiagonal{Float64,Vector{Float64}},
    E_Tm::Vector{Float64}, V_Tm::Matrix{Float64}, Ex::Vector{Float64},
    Ey::Vector{Float64}, E_edge::Vector{Float64}, z_wght::Vector{Float64})

    dE = 0.0
    E_up = 0.0
    E_low = 0.0
    E_max = 0.0
    ak = 0.0
    bk = 0.0

    @inbounds for jv in 1:Nv
        #----------------------------------------
        # Initial random vector
        randn!(v0)
        bk = 0.0
        @simd for i in 1:N
            bk += v0[i]^2
        end
        bk = sqrt(bk)

        invbk = 1/bk
        @simd for i in 1:N
            v0[i] *= invbk
            Qm[i,1] = v0[i]
        end

        #----------------------------------------
        # First Lanczos coefficient
        mul!(vk, M, v0)

        ak = 0.0
        @simd for i in 1:N
            ak += v0[i] * vk[i]
        end
        pot[1] = ak

        @simd for i in 1:N
            vk[i] -= ak * v0[i]
        end

        bk = 0.0
        @simd for i in 1:N
            bk += vk[i]^2
        end
        bk = sqrt(bk)
        hop[1] = bk

        #----------------------------------------
        # Main Lanczos loop
        @inbounds for j in 2:m
            # v1 = previous v0
            @simd for i in 1:N
                v1[i] = v0[i]
            end

            # v0 = new normalized vk
            invbk = 1/bk
            @simd for i in 1:N
                v0[i] = vk[i] * invbk
                Qm[i,j] = v0[i]
            end

            mul!(vk, M, v0)

            # vk = vk - bk * v1
            @simd for i in 1:N
                vk[i] -= bk * v1[i]
            end

            # ak = dot(v0, vk)
            ak = 0.0
            @simd for i in 1:N
                ak += v0[i] * vk[i]
            end
            pot[j] = ak

            # vk -= ak * v0
            @simd for i in 1:N
                vk[i] -= ak * v0[i]
            end

            # Full Gram-Schmidt
            @inbounds for q in 1:j-1
                dq = 0.0
                colQ = @view Qm[:,q]   # does NOT allocate (view on matrix)
                @simd for i in 1:N
                    dq += colQ[i] * vk[i]
                end
                @simd for i in 1:N
                    vk[i] -= dq * colQ[i]
                end
            end

            # Next bk
            bk = 0.0
            @simd for i in 1:N
                bk += vk[i]^2
            end
            bk = sqrt(bk)
            hop[j] = bk
        end

        #----------------------------------------
        # Build Tm in-place (NO allocation)
        @inbounds for i in 1:m
            Tm.dv[i] = pot[i]
        end
        @inbounds for i in 1:m-1
            Tm.ev[i] = hop[i]
        end

        E_strc = eigen(Tm)           # allocates small arrays of size m
        @inbounds for i in 1:m
            E_Tm[i] = E_strc.values[i]
        end
        copyto!(view(V_Tm, 1:m, 1:m), E_strc.vectors)
        #----------------------------------------
        # Energy range (only first random vector)
        if jv == 1
            E_up = E_Tm[m] + hop[m] * abs(V_Tm[m,m])
            E_low = E_Tm[1] - hop[m] * abs(V_Tm[m,1])

            # bin edges
            ΔE = (E_up - E_low) / lEx
            cur = E_low
            @inbounds for i in 1:lEx+1
                E_edge[i] = cur
                cur += ΔE
            end

            # midpoints
            @inbounds for i in 1:lEx
                Ex[i] = 0.5 * (E_edge[i] + E_edge[i+1])
            end
        end

        #----------------------------------------
        # Compute weights: z_wght[j] = V_Tm[1,j]^2
        @inbounds @simd for j in 1:m
            z_wght[j] = V_Tm[1,j] * V_Tm[1,j]
        end

        dE = Ex[2] - Ex[1]

        #----------------------------------------
        # Add Lorentzian broadened peaks
        @inbounds for j in 1:m
            ej = E_Tm[j]
            w = z_wght[j] * dE / π
            @inbounds @simd for i in 1:lEx
                Ey[i] += w / (dE^2 + (Ex[i] - ej)^2)
            end
        end
    end

    #   Estimate of DOS
    Ey ./= Nv;
end
#   ===================================================
#   Calculate energy moments
function f_E_mom!(N_H::Int, Nv::Int,
    H::SparseMatrixCSC{Float64,Int},
    v0::Vector{Float64}, v1::Vector{Float64}, v2::Vector{Float64},
    E_mom_arr::Vector{Float64})

    fill!(E_mom_arr, 0.0)

    # <E>
    E_mom_arr[1] = sum(@view(H[1:N_H+1:end])) / N_H

    norm_fac = 1.0 / (Nv * N_H)

    @inbounds for j in 1:Nv

        # Ψ = random vector
        randn!(v0)

        #-----------------------------------
        # Compute v1 = H|Ψ>
        mul!(v1, H, v0)

        # <E²> = ⟨HΨ | HΨ⟩
        E_mom_arr[2] += dot(v1, v1) * norm_fac

        #-----------------------------------
        # Compute v2 = H²|Ψ>
        mul!(v2, H, v1)

        # <E³> = ⟨HΨ | H²Ψ⟩
        E_mom_arr[3] += dot(v1, v2) * norm_fac

        # <E⁴> = ⟨H²Ψ | H²Ψ⟩
        E_mom_arr[4] += dot(v2, v2) * norm_fac
    end
end

end # module DOSModule
