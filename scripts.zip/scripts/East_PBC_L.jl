#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
#   Functions for ground state
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")

using .H_EastModule, .GSModule, LinearAlgebra, DelimitedFiles, Printf
#   ===================================================
#=
1D East model with periodic boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
eigenvalues, Dq, entanglement entropy

---Parameter descriptions---
L = Number of particles
=#
#   ===================================================
ftype = "East_L_PBC_full";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B
#   ======================================
#   Preallocate arrays
H_East_dense = zeros(N_H, N_H);
E_East = zeros(N_H);

v_to_M = zeros(NA, NB);
#   ======================================
stats = @timed begin
    #   East Hamiltonian with PBC
    H_East = f_H_East_PBC_L(L, N_H);

    #   Exact diagonalization
    V_East = f_ED!(N_H, H_East_dense, H_East, E_East);

    #   Printing data
    fname_E_East = @sprintf("%s_%s_%02d.dat", ftype, "e", L);
    writedlm(fname_E_East, E_East, '\n');

    fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN", L);
    fid_SvN = open(fname_SvN, "w");

    @inbounds for state in 1:N_H
        #   Bipartite von Neumann entanglement entropy
        SvN = f_SvN!(L, V_East[:, state], v_to_M);
        writedlm(fid_SvN, SvN, '\t');
    end
    close(fid_SvN);
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
