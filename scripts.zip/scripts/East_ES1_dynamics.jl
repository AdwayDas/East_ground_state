include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
include("/home/adway/01.Works/01.CPU/21.East/scripts/DynamicsModule.jl")
using .H_EastModule, .DynamicsModule, LinearAlgebra, DelimitedFiles, Printf, Random
#   ===================================================
#=
    ⋅   1D East model with East boundary condition
    ⋅   Dynamics of |ES1>

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1])        #   Number of sites
const s = parse(Float64, ARGS[2])

#   Hilbert space dimension
const N_H = 2^L;
#   Time
tH = 2^L/sqrt(L/2+3/4);                 #   Heisenberg time
#   Evolution uses H_code = 2eˢ H_East (Eq. (1)); t_arr is in units of (2eˢ)⁻¹
const t_arr = collect(range(0, 512; length=2^12)); const lt = length(t_arr);
#   Stored time in units of Eq. (1): t = 2eˢ t_code
fname_t = @sprintf("%s_%s_%02d_%+4.2f.dat", ftype, "ES1_time", L, s)
writedlm(fname_t, 2*exp(s) .* t_arr, '\n');
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H)
#   Initial state
vα = Vector{Float64}(undef, N_H)
#   Time evolved state
tmp = Vector{ComplexF64}(undef, N_H)
Ψt = Vector{ComplexF64}(undef, N_H)

SP_arr = Vector{Float64}(undef, lt)
n_M = Matrix{Float64}(undef, lt, L)
sx_M = Matrix{ComplexF64}(undef, lt, L)
#   ======================================

stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H)
    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_update_diag!(L, N_H, exp(s), E_East, H_East)
    
    #   Full exact diagonalization
    println("ED...")
    H = collect(H_East)
    F = eigen!(Symmetric(H, :U))
    E_East .= F.values; V_East = F.vectors;

    #   Coherent initial state: |ES1>
    #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
    theta_arr = zeros(L); fill!(theta_arr, π/3); theta_arr[1] = 4*π/3
    Ψ = f_spin_c_state(L, theta_arr)

    #   Dynamics
    println("|ES1>...")
    f_dynamics_ED!(L, N_H, V_East, E_East, lt, t_arr, Ψ, vα, tmp, Ψt,
        SP_arr, n_M, sx_M)

    #   Store data
    fname_SP = @sprintf("%s_%s_%02d_%+4.2f.dat", ftype, "ES1_SP", L, s)
    writedlm(fname_SP, SP_arr, '\n')
    fname_n = @sprintf("%s_%s_%02d_%+4.2f.dat", ftype, "ES1_n", L, s)
    writedlm(fname_n, n_M, '\t')
    fname_n = @sprintf("%s_%s_%02d_%+4.2f.dat", ftype, "ES1_sx", L, s)
    writedlm(fname_n, real.(sx_M), '\t')
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
