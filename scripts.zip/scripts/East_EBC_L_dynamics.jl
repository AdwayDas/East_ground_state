#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
include("/home/adway/01.Works/01.CPU/21.East/scripts/DynamicsModule.jl")
using .H_EastModule, .DynamicsModule, LinearAlgebra, Expokit, LinearMaps, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Dynamics of spin-coherent states

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East_L";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   Time
tH = 2^L/sqrt(L/2+3/4);                 #   Heisenberg time
const t_arr = collect(range(0, 4*tH; length=2^10)); const lt = length(t_arr);
const dt = t_arr[2] - t_arr[1]
writedlm("time.dat", t_arr, '\n');

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H)
#   Initial state
Ψ = Vector{Float64}(undef, N_H)
#   Time evolved state
tmp = Vector{ComplexF64}(undef, N_H)
Ψt = Vector{ComplexF64}(undef, N_H)
#   Observables
SP_arr = Vector{Float64}(undef, lt)
n_M = Matrix{Float64}(undef, lt, L)
sx_M = Matrix{ComplexF64}(undef, lt, L)
SvN_arr = Vector{Float64}(undef, lt)
v_to_M = Matrix{ComplexF64}(undef, NA, NB);
#   ======================================
#   Filenames
fname_SP = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin-sup", L);
fid_SP = open(fname_SP, "w");

fname_n = @sprintf("%s_%s_%02d.dat", ftype, "n_spin-sup", L);
fid_n = open(fname_n, "w");

fname_sx_real = @sprintf("%s_%s_%02d.dat", ftype, "sx_real_spin-sup", L);
fid_sx_real = open(fname_sx_real, "w");
fname_sx_imag = @sprintf("%s_%s_%02d.dat", ftype, "sx_imag_spin-sup", L);
fid_sx_imag = open(fname_sx_imag, "w");

fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN_spin-sup", L);
fid_SvN = open(fname_SvN, "w");
#   ======================================
stats = @timed begin
    println("Constructing Hamiltonian...")
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_L_off(L, N_H);
    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);

    # Lazy operator using LinearMap
    A = LinearMap(v -> -1im*(H_East*v), N_H, N_H)

    # Provide anorm to suppress warning in Expokit
    anorm_est = norm(H_East, Inf)

    theta_vals = [π/4; π/3; 5*π/12]; l_theta = length(theta_vals);
    theta_arr = zeros(L); 

    for j in 1:(l_theta+L)
        println("j: ", j)
        #   Initial state
        if j <= l_theta
            θ = theta_vals[j]
            Ψ .= f_spin_pol_state(L, θ);
            Ψ .+= f_spin_pol_state(L, 2*π - θ);
            normalize!(Ψ)
        else
            fill!(theta_arr, π/3); theta_arr[j-l_theta] = 4*π/3
            Ψ .= f_spin_c_state(L, theta_arr);
            fill!(theta_arr, 5*π/3); theta_arr[j-l_theta] = 2*π/3
            Ψ .+= f_spin_c_state(L, theta_arr);
            normalize!(Ψ)
        end
    
        #   Survival probability
        f_dynamics_expo!(L, N_H, A, Ψ,
                dt, lt, anorm_est, tmp, Ψt,
                SP_arr, n_M, sx_M, SvN_arr, v_to_M);
        #   Average over sites
        n_arr = sum(n_M, dims=2); sx_arr = sum(sx_M, dims=2);
        n_arr ./= L; sx_arr ./= L;
        #   Store data
        writedlm(fid_SP, transpose(SP_arr), '\t');
        writedlm(fid_n, transpose(n_arr), '\t');
        writedlm(fid_sx_real, transpose(real.(sx_arr)), '\t');
        writedlm(fid_sx_imag, transpose(imag.(sx_arr)), '\t');
        writedlm(fid_SvN, transpose(SvN_arr), '\t');
    end
    close(fid_SP);
    close(fid_n);
    close(fid_sx_real); close(fid_sx_imag);
    close(fid_SvN);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end