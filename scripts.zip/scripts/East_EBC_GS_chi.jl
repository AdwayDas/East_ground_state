include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")
using .H_EastModule, .GSModule, LinearAlgebra, DelimitedFiles, Printf

#   ======================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   System parameters
s_arr = vcat(collect(-0.2:0.02:-0.04), collect(-0.03:4e-3:0.05), collect(0.06:0.02:0.2))
#   ===================================================
#   Internal parameters
#   ===================================================
#   Precision in energy estimate
const Nv = 8;   #   Number of repetitions for m-step Lanczos
const m = 16;   #   Number of Lanczos steps

const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
#   Preallocate arrays
V_diag = zeros(N_H);
v0 = zeros(N_H);
v1 = zeros(N_H);
v2 = zeros(N_H);
a_wall = Array{Float64}(undef, m_wall);

#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);
#   ======================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = f_wall_node(m_wall);

    #   Off-diagonal part of East Hamiltonian with s → -∞
    H_EBC_L = f_H_East_EBC_L_off(L, N_H)
    #   Update diagonal part of East Hamiltonian with s → -∞
    f_H_East_EBC_L_update_diag!(L, N_H, V_diag, H_EBC_L)
    
    H = similar(H_EBC_L)

    #   Filename
    fname = @sprintf("%s_%s_%02d.dat", ftype, "GS_chi", L);
    fid = open(fname, "w");

    for s in s_arr          #   Loop for system parameter
        @printf("s: %+6.3f\n", s)
        #   (I + N)/(2 eˢ)
        f_H_East_EBC_L_perturb!(L, s, V_diag)

        copyto!(H, H_EBC_L)
        @inbounds @simd for i in 1:N_H
            H[i, i] += V_diag[i] * 2 * exp(2 * s)
        end

        #   Estimate energy bounds from m-step Lanczos reduction
        global v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm;
        E_low, E_up = f_E_bound_Lanczos!(N_H, m, Nv, H, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm)

        #   Ground state energy using wall-Chebyshev method
        global a_wall;
        EG, j_wall = f_Wall!(exp(s), E_low, E_up, E_tol, m_wall, n_wall, H, a_wall_scld, a_wall, v0, v1)

        #   Fidelity-susceptibility of ground state
        chi = f_GS_chi!(s, N_H, H_EBC_L, V_diag, EG, v0, v1, vk)

        #   Store data
        writedlm(fid, [s chi], '\t')
    end
    close(fid)
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end