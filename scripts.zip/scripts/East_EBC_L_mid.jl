#   ===================================================
using SparseArrays, LinearAlgebra, Random, Arpack, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")  # loads the file with ground state functions
using .GSModule         # dot means “from current project/folder”
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Few states from the middle of the spectrum

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
#   Off-diagonal terms of number operator at kth site (bit k-1), <Eᵢ|nₖ|Eⱼ>
function f_nk_ij(N_H::Int, k::Int, Ei::Vector{Float64}, Ej::Vector{Float64})
    nk_ij = 0.0
    mask_k = UInt64(1) << (k-1)

    @inbounds for state in 0:N_H-1
        #   nₖ is diagonal: only states with kth spin up contribute
        if UInt64(state) & mask_k != 0
            nk_ij += Ei[state + 1] * Ej[state + 1]
        end
    end

    return nk_ij
end
#   ===================================================
ftype = "East_L";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;
#   Number of states obtained
const nev = 256
#   Target energy
E_trgt = -0.5

#   q values for Dq analysis
const qx = vcat(collect(0:0.1:1-0.1), collect(1+0.1:0.1:5), collect(6:30));
const lq = length(qx);
logL_qx = log(N_H).*(1 .- qx);
fname_qx = @sprintf("%s.dat", "qx");
fid_qx = open(fname_qx, "w");
writedlm(fid_qx, qx, '\t'); close(fid_qx);

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B

L_half = div(L, 2);
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
n_arr = Vector{Float64}(undef, L);
Dq_arr = Vector{Float64}(undef, lq);
v_to_M = zeros(NA, NB);

v0 = Vector{Float64}(undef, N_H);
v1 = Vector{Float64}(undef, N_H);

n_corr = div(nev*(nev-1), 2);
corr_M = Array{Float64}(undef, n_corr, 4);
#   ======================================
#   Filenames
#   ======================================
#   Number density
fname_n_dnsty = @sprintf("%s_%s_%02d.dat", ftype, "n_dnsty", L);
fid_n_dnsty = open(fname_n_dnsty, "w");

#   Fractal dimensions
fname_Dq = @sprintf("%s_%s_%02d.dat", ftype, "Dq", L);
fname_Dmax = @sprintf("%s_%s_%02d.dat", ftype, "Dmax", L);
fid_Dq = open(fname_Dq, "w");
fid_Dmax = open(fname_Dmax, "w");

#   von Neumann entanglement entropy
fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN", L);
fid_SvN = open(fname_SvN, "w");
#   ======================================
stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = H_EastModule.f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    E_East = zeros(Float64, N_H);
    H_EastModule.f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);

    #   nev number of eigenvalues from the middle of the spectrum: Shift-invert
    E_arr, V_M = eigs(H_East, nev=nev, which=:LM, tol=0.0, sigma=E_trgt, ritzvec=true);
    #   Sort eigenvalues and vectors
    p = sortperm(E_arr)
    tmp = similar(V_M)
    @views tmp .= V_M[:, p]
    @views V_M .= tmp
    sort!(E_arr)

    fname_E_mid = @sprintf("%s_%s_%02d.dat", ftype, "E_mid", L);
    writedlm(fname_E_mid, E_arr, '\t');
    #   ======================================
    #   Observables w.r.t. single eigenstate
    #   ======================================
    @inbounds for j in 1:nev
        copyto!(v0, @view(V_M[:, j]))

        #   Number density, <nᵢ>
        global n_arr;
        f_num_dnsty!(L, N_H, v0, n_arr);
        writedlm(fid_n_dnsty, transpose(n_arr), '\t');

        #   Fractal dimensions
        Dmax = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
        writedlm(fid_Dq, transpose(Dq_arr), '\t');
        writedlm(fid_Dmax, Dmax, '\t');

        #   Bipartite von Neumann entanglement entropy
        SvN = f_SvN!(L, v0, v_to_M);
        writedlm(fid_SvN, SvN, '\t');
    end
    close(fid_n_dnsty);
    close(fid_Dq);
    close(fid_Dmax);
    close(fid_SvN);
    #   ======================================
    #   Eigenstate correlations
    #   ======================================
    ij = 1;
    @inbounds for i in 1:nev-1
        copyto!(v0, @view(V_M[:, i]))
        @inbounds for j in i+1:nev
            copyto!(v1, @view(V_M[:, j]))

            #   Average energy
            corr_M[ij, 1] = (E_arr[j] + E_arr[i])/2

            #   Energy difference
            corr_M[ij, 2] = E_arr[j] - E_arr[i]

            #   Overlap
            corr_M[ij, 3] = dot(v0.^2, v1.^2)

            #   <Eᵢ|nₖ|Eⱼ>, k = L/2
            corr_M[ij, 4] = f_nk_ij(N_H, L_half, v0, v1)

            global ij += 1;
        end
    end
    #   Store data
    fname_corr = @sprintf("%s_%s_%02d.dat", ftype, "state_corr", L);
    writedlm(fname_corr, corr_M, '\t');
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end