#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")

using .H_EastModule, LinearAlgebra, DelimitedFiles, Printf
#   ===================================================
#=
1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
Overlap of possible quantum scar with eigenstates

---Parameter descriptions---
L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites
const s = parse(Float64, ARGS[2]);

#   Hilbert space dimension
const N_H = 2^L;
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
H_East_dense = zeros(N_H, N_H)
#   ======================================
stats = @timed begin
    println("Constructing Hamiltonian...")
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);
    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_update_diag!(L, N_H, exp(s), E_East, H_East);

    #   Exact diagonalization
    println("Exact diagonalization...")
    V_East = f_ED!(N_H, H_East_dense, H_East, E_East);

    #   |π/3>^(L-1) ⊗ |4π/3>
    #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
    theta_arr = zeros(L); fill!(theta_arr, π/3); theta_arr[1] = 4*π/3
    Ψ = f_spin_c_state(L, theta_arr);
    olap_arr = abs2.(V_East' * Ψ)

    fname_olap = @sprintf("%s_%s_%02d_%+5.2f.dat", ftype, "olap", L, s);
    writedlm(fname_olap, hcat(E_East, olap_arr), '\t');
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
