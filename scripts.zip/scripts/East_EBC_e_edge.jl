#   ===================================================
using SparseArrays, Arpack, LinearAlgebra, Random, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule
#   ===================================================
#=
    ⋅   1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
    ⋅   Few eigenvalues from the edge of the spectrum

    ---Parameter descriptions---
    L = Number of particles
    s = system parameter
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);    #   Number of sites
const nev = parse(Int64, ARGS[2]);  #   Number of eigenvalues obtained

#   System parameters
s_arr = -0.5:0.1:1.5
# vcat(collect(-1:0.1:-0.1), collect(-0.08:0.02:0.08), collect(0.1:0.1:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
fid_s_vals = open(fname_s_vals, "w");
writedlm(fid_s_vals, s_arr, '\t'); close(fid_s_vals);

#   Hilbert space dimension
const N_H = 2^L;
#   ===================================================
#   Internal parameters
const Nv = 8;   #   Number of repetitions for m-step Lanczos
const m = 16;   #   Number of Lanczos steps
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
#   Preallocate arrays
ax = Array{Int64}(undef, 2^L);
j0 = Array{Int64}(undef, 2^(L-1));
j1 = Array{Int64}(undef, 2^(L-1));
k_ind = Array{Int64}(undef, 2^(L-2));
l_ind = Array{Int64}(undef, 2^(L-2));

E_East = zeros(N_H);
#   ======================================
stats = @timed begin
    #   ==================================
    #   Filename
    fname_E_edge = @sprintf("%s_%s_%02d.dat", ftype, "E_edge", L);
    fid_E_edge = open(fname_E_edge, "w");
    #   ==================================
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s);
        @printf("s: %+5.2f\n", s);

        #   Update diagonal part of East Hamiltonian
        global E_East, ax, j1, H_East;
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   nev number of eigenvalues from the edge of the spectrum
        E_arr, v = eigs(H_East, nev=nev, which=:SR, tol=0.0, sigma=nothing, ritzvec=false);
        #   Overall multiplicative factor
        E_arr ./= 2*Γ;

        #   Printing data
        writedlm(fid_E_edge, transpose(E_arr), '\t');
    end                     #   Loop for system parameter closed
    close(fid_E_edge);
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
