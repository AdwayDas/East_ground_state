include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")

using .H_EastModule, SparseArrays, LinearAlgebra, Arpack, DelimitedFiles, Printf, Plots
#   ===================================================
#=
    ⋅   1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
    ⋅   Local density of states of |ES_1>

    ---Parameter descriptions---
    L = Number of particles
    s = system parameter
=#
#   ===================================================
#   m-step Lanczos reduction
#   ===================================================
function f_m_Lanczos(N::Int, m::Int,
    H::SparseMatrixCSC{Float64, Int},
    Ψ::Vector{Float64}
)
    #   Work vectors
    v0 = copy(Ψ); v1 = similar(v0); vk = similar(v0)
    #   Tolerance value for stopping Lanczos iteration
    tol = sqrt(eps(Float64))
    #   Krylov basis (N × m)
    Qm = Array{Float64}(undef, N, m)
    #   Tridiagonal matrix in the Krylov space
    pot = Array{Float64}(undef, m)
    hop = Array{Float64}(undef, m)

    @views copyto!(Qm[:, 1], v0)

    # vk = H * q1
    mul!(vk, H, v0)

    # a1
    ak = dot(v0, vk)
    pot[1] = ak

    # vk -= a1 * q1
    @inbounds @. vk -= ak * v0

    # b1
    bk = norm(vk)

    # effective Lanczos dimension
    m_eff = 1

    if bk < tol
        hop .= 0.0
    else
        hop[1] = bk
        copyto!(v1, v0)   # q_{j-1} = q1

        # --- Lanczos loop ---
        for j in 2:m
            # q_j = vk / b_{j-1}
            @inbounds @. v0 = vk / bk
            @views copyto!(Qm[:, j], v0)

            # vk = H * q_j
            mul!(vk, H, v0)

            # vk -= b_{j-1} * q_{j-1}
            @inbounds @. vk -= bk * v1

            # a_j
            ak = dot(v0, vk)
            pot[j] = ak

            # vk -= a_j * q_j
            @inbounds @. vk -= ak * v0

            # --- full reorthogonalization ---
            for iQ in 1:(j-1)
                @views q = Qm[:, iQ]
                c = dot(q, vk)
                LinearAlgebra.BLAS.axpy!(-c, q, vk)
            end

            # b_j
            bk = norm(vk)
            m_eff = j

            hop[j] = bk

            if bk < tol
                break
            end

            copyto!(v1, v0)
        end
    end

    # --- build Tm (only up to m_eff) ---
    Tm = SymTridiagonal(@view(pot[1:m_eff]), @view(hop[1:(m_eff-1)]))

    egn = eigen!(Tm)

    return m_eff, egn.values, egn.vectors, Qm[:, 1:m_eff], hop[1:m_eff]
end
#   ===================================================
#   Local density of states (LDOS)
#   ===================================================
function f_LDOS(N::Int, m::Int, lEx::Int,
    H::SparseMatrixCSC{Float64, Int},
    Ψ::Vector{Float64})

    #   Effective Krylov dimension, Ritz values and vectors, Krylov basis, off-diagonal Lanczos terms
    m_eff, E_Tm, V_Tm, Qm, hop = f_m_Lanczos(N, m, H, Ψ)

    #   Energy bounds
    E_up = E_Tm[m_eff] + hop[m_eff] * abs(V_Tm[m_eff, m_eff])
    E_low = E_Tm[1] - hop[m_eff] * abs(V_Tm[m_eff, 1])

    # bin edges
    E_edge = collect(LinRange(E_low, E_up, lEx+1))
    
    # midpoints
    Ex = (E_edge[2:end] .+ E_edge[1:end-1])./2
    dE = Ex[2] - Ex[1]
    Ey = zeros(lEx)

    η = 2*dE   #   Lorentzian broadening parameter

    #   Add Lorentzian broadened peaks
    @inbounds for j in 1:m_eff
        ej = E_Tm[j]
        w = V_Tm[1, j]^2 * η / π
        @inbounds @simd for i in 1:lEx
            Ey[i] += w / (η^2 + (Ex[i] - ej)^2)
        end
    end
    #   Normalize
    Ey ./= sum(Ey .* dE)

    return Ex, Ey
end
#   ===================================================
#   End of function definitions
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites
const s = parse(Float64, ARGS[2]);      #   Number of sites

#   Hilbert space dimension
const N_H = 2^L
#   Number of Lanczos steps
const m = 256
#   Length of array for histogram
const lEx = 256
#   Number of eigenvalues computed using ARPACK
if s < -1.0
    nev = 50
else
    nev = 256
end

#   Preallocate arrays
E_East = zeros(N_H)
#   ======================================
stats = @timed begin

    #   Initial state: |ES_1>
    #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
    theta_arr = zeros(L); fill!(theta_arr, π/3); theta_arr[1] = 4*π/3
    Ψ = f_spin_c_state(L, theta_arr)

    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H)

    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_update_diag!(L, N_H, exp(s), E_East, H_East)
    #   ======================================
    println("Calculating LDOS ...")
    #   Local density of states (LDOS)
    Ex, Ey = f_LDOS(N_H, m, lEx, H_East, Ψ)

    #   Largest peak in the LDOS
    val, j = findmax(Ey)
    E_trgt = Ex[j]
    #   ======================================
    #   Exact diagonalization using ARPACK
    println("ED using Arpack ...")
    E_arr, V = eigs(H_East; nev=nev, sigma=E_trgt, which=:LM, tol=1e-8, maxiter=1000)

    olap_arr = zeros(nev)
    for i in 1:nev
        olap_arr[i] = abs2(dot(Ψ, V[:, i]))
    end

    p = sortperm(E_arr)
    E_arr = E_arr[p]; olap_arr = olap_arr[p]

    i1, i2 = sortperm(olap_arr, rev=true)[1:2]

    #   ======================================
    #   Printing data
    #   Taking care of global factor of the Hamiltonian
    Ex .*= exp(-s)/2.0; Ey ./= exp(-s)/2.0
    E_trgt *= exp(-s)/2.0; E_arr .*= exp(-s)/2.0
    
    fname = @sprintf("%s_%s_%02d_%+5.2f.dat", ftype, "ES1_LDOS", L, s)
    writedlm(fname, hcat(Ex, Ey))

    fname = @sprintf("%s_%s_%02d_%+5.2f.dat", ftype, "ES1_olap", L, s)
    writedlm(fname, hcat(E_arr, olap_arr))

    fname = @sprintf("%s_%s_%02d_%+5.2f.dat", ftype, "ES1_energies", L, s)
    writedlm(fname, [E_trgt; E_arr[i1]; E_arr[i2]])
end
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end