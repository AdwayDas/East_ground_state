include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
#   Functions for ground state
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")

using .H_EastModule, .GSModule, LinearAlgebra, DelimitedFiles, Printf

#   ===================================================
#=
    ⋅   1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
    ⋅   Spectral function of π-pulse on the ground state

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   System parameters
s_arr = vcat(collect(-1:0.1:0), collect(0.2:0.4:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
writedlm(fname_s_vals, s_arr, '\t');

#   Hilbert space dimension
const N_H = 2^L;
#   ===================================================
#   Internal parameters
#   ===================================================
const Nv = 8;   #   Number of repetitions for m-step Lanczos for energy bound
const m = 16;   #   Number of Lanczos steps for energy bound
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   Number of Lanczos steps for spectral function
const m_spectral = 64;
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
v0 = zeros(N_H);
v1 = zeros(N_H);
vk = zeros(N_H);
a_wall = Array{Float64}(undef, m_wall);

#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);
#   ===================================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = f_wall_node(m_wall);

    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s); println("s: ", s);

        #   Update diagonal part of East Hamiltonian
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Estimate energy bounds from m-step Lanczos reduction
        global v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm;
        E_low, E_up = f_E_bound_Lanczos!(N_H, m, Nv, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm);

        #   Ground state using wall-Chebyshev method
        EG, j_wall = f_Wall!(Γ, E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1);

        #   π-pulse on the ground state around Y-axis on the first site (creates |•_1>)
        v1 .= f_pi_pulse_Y(L, 1, v0);

        #   m-step Lanczos reduction starting from the π-pulsed state
        m_eff, E_pi, V_pi = f_m_Lanczos_v0!(N_H, m_spectral, H_East, v1);
        #   Accounting for global factor in the Hamiltonian
        E_pi ./= 2*Γ;

        #   Store data for spectral function
        fname = @sprintf("%s_%s_%02d_%+05.2f.dat", ftype, "spectral_pi_pulse", L, s);
        writedlm(fname, [E_pi .- EG V_pi[1, :].^2], '\t');
    end
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end

