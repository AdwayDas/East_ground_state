#   ===================================================
#   Functions for Hamiltonian
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
#   Functions for ground state
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")

using .H_EastModule, .GSModule, LinearAlgebra, Optim, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Anti-ground state properties

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
#   End of function definitions
#   ===================================================
ftype = "East_L";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   q values for Dq analysis
const qx = vcat(collect(0:0.1:1-0.1), collect(1+0.1:0.1:5), collect(5.4:0.4:10), collect(11:30));
const lq = length(qx);
logL_qx = log(N_H).*(1 .- qx);
fname_qx = @sprintf("%s.dat", "qx");
fid_qx = open(fname_qx, "w");
writedlm(fid_qx, qx, '\t'); close(fid_qx);

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B
#   ===================================================
#   Internal parameters
#   ===================================================
#   Estimtes for lower and upper bounds of spectrum
E_low = -1 - sqrt(3)*(3*L+1)/8; E_up = 1 + sqrt(3)*(3*L+1)/8;
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
#   Preallocate arrays
v0 = zeros(N_H);
v1 = zeros(N_H);
v2 = zeros(N_H);
a_wall = Array{Float64}(undef, m_wall);
n_arr = Array{Float64}(undef, L);
n_corr = Array{Float64}(undef, L-1);
Dq_arr = Array{Float64}(undef, lq);
v_to_M = zeros(NA, NB);
#   ======================================
#   Filenames
#   ======================================
#   Anti-ground state energy
fname_E_AS = @sprintf("%s_%s_%02d.dat", ftype, "E_AS", L);
fid_E_AS = open(fname_E_AS, "w");

#   Number density w.r.t. anti-ground state
fname_n_dnsty = @sprintf("%s_%s_%02d.dat", ftype, "n_dnsty_AS", L);
fid_n_dnsty = open(fname_n_dnsty, "w");

#   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ> w.r.t. anti-ground state
fname_n_nr = @sprintf("%s_%s_%02d.dat", ftype, "n_nr_AS", L);
fid_n_nr = open(fname_n_nr, "w");

#   Magnetization in X-direction, <σˣᵢ> w.r.t. anti-ground state
fname_sx = @sprintf("%s_%s_%02d.dat", ftype, "sx_AS", L);
fid_sx = open(fname_sx, "w");

#   Fractal dimensions
fname_Dq = @sprintf("%s_%s_%02d.dat", ftype, "Dq_sz", L);
fname_Dmax = @sprintf("%s_%s_%02d.dat", ftype, "Dmax_sz", L);
fid_Dq = open(fname_Dq, "w");
fid_Dmax = open(fname_Dmax, "w");

#   Fractal dimensions in σˣ basis
fname_Dq_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dq_sx", L);
fname_Dmax_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dmax_sx", L);
fid_Dq_sx = open(fname_Dq_sx, "w");
fid_Dmax_sx = open(fname_Dmax_sx, "w");

#   von Neumann entanglement entropy
fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN", L);
fid_SvN = open(fname_SvN, "w");
#   ======================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = f_wall_node(m_wall);
    
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_L_update_diag!(L, N_H, v1, H_East);
    #   Ground state of -H = anti-ground state of H
    H_East .*= -1.0;

    #   Ground state energy using wall-Chebyshev method
    global a_wall;
    EG, j_wall = f_Wall!(0.5, E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1);
    writedlm(fid_E_AS, -EG, '\t'); close(fid_E_AS);
    #   ======================================
    #   Spin-coherent approximation
    #   ======================================
    #   Polarized spin-coherent state |5π/3>^{⊗L} (kept for comparison)
    v1 .= f_spin_pol_state(L, 5*π/3);
    olap = dot(v0, v1);
    fname = @sprintf("%s_%s_%02d.dat", ftype, "spin-pol_AS_overlap", L);
    writedlm(fname, olap^2, '\t');

    #   Anti-ground state ansatz, Eq. (8): |5π/3>^{⊗L-1} ⊗ |•>, |•> = |4π/3> on site L
    #   (image of |Θ> under the chiral symmetry ⊗_{j<L} σᶻⱼ σʸ_L, so the overlap equals |<GS|Θ>|²)
    theta_arr = fill(5*π/3, L); theta_arr[L] = 4*π/3;
    v1 .= f_spin_c_state(L, theta_arr);
    olap = dot(v0, v1);
    fname = @sprintf("%s_%s_%02d.dat", ftype, "spin-c_AS_overlap", L);
    writedlm(fname, olap^2, '\t');

    #   Projecting out the ansatz of Eq. (8)
    v2 .= v0; v2 .-= olap.*v1; normalize!(v2);

    #   ======================================
    #   Observables
    #   ======================================
    #   Number density, <nᵢ> w.r.t. anti-ground state
    global n_arr;
    f_num_dnsty!(L, N_H, v0, n_arr);
    writedlm(fid_n_dnsty, n_arr', '\t');
    #   Number density w.r.t. v2
    f_num_dnsty!(L, N_H, v2, n_arr);
    writedlm(fid_n_dnsty, n_arr', '\t'); close(fid_n_dnsty);

    #   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ> w.r.t. anti-ground state
    global n_corr;
    f_dnsty_corr!(L, N_H, v0, n_arr, n_corr);
    writedlm(fid_n_nr, n_corr', '\t'); close(fid_n_nr);

    #   Magnetization in X-direction, <σˣᵢ> w.r.t. anti-ground state
    f_sx_avg!(L, N_H, v0, n_arr);
    writedlm(fid_sx, n_arr', '\t');
    #   Magnetization in X-direction, <σˣᵢ> w.r.t. v2
    f_sx_avg!(L, N_H, v2, n_arr);
    writedlm(fid_sx, n_arr', '\t'); close(fid_sx);

    #   Fractal dimensions of anti-ground state
    Dmax = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq, Dq_arr', '\t');
    writedlm(fid_Dmax, Dmax, '\t');
    #   Fractal dimensions of v2
    Dmax = f_Dq!(N_H, lq, v2, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq, Dq_arr', '\t');
    writedlm(fid_Dmax, Dmax, '\t');

    close(fid_Dq); close(fid_Dmax);

    #   Bipartite von Neumann entanglement entropy
    SvN = f_SvN!(L, v0, v_to_M);
    writedlm(fid_SvN, SvN, '\t'); close(fid_SvN);
    #   Entanglement entropy of v2 for different bipartitions
    SvN_arr = f_SvN_all(L, v2);
    fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN_all_v2", L);
    writedlm(fname_SvN, SvN_arr, '\n');
        
    #   Represent the anti-ground state in σˣ basis
    trnsfrm_sz_to_sx!(N_H, v0);

    #   Fractal dimensions in σˣ basis
    Dmax_sx = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq_sx, Dq_arr', '\t');
    writedlm(fid_Dmax_sx, Dmax_sx, '\t');

    #   Represent v2 in σˣ basis
    trnsfrm_sz_to_sx!(N_H, v2);

    #   Fractal dimensions in σˣ basis
    Dmax_sx = f_Dq!(N_H, lq, v2, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq_sx, Dq_arr', '\t');
    writedlm(fid_Dmax_sx, Dmax_sx, '\t');

    close(fid_Dq_sx); close(fid_Dmax_sx);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end