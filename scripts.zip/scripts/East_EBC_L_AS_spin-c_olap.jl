#   ===================================================
#   Functions for Hamiltonian
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
#   Functions for ground state
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")

using .H_EastModule, .GSModule, LinearAlgebra, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Overlap of the anti-ground state with its spin-coherent ansatz, Eq. (8):
        |AS> ≈ |5π/3>^{⊗L-1} ⊗ |•>,  |•> = |4π/3> on site L
        (image of |Θ> under the chiral symmetry ⊗_{j<L} σᶻⱼ σʸ_L, so the overlap equals |<GS|Θ>|²)

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East_L";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;
#   ===================================================
#   Internal parameters
#   ===================================================
#   Estimtes for lower and upper bounds of spectrum
E_low = -1 - sqrt(3)*(3*L+1)/8; E_up = 1 + sqrt(3)*(3*L+1)/8;
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
#   Preallocate arrays
v0 = zeros(N_H);
v1 = zeros(N_H);
a_wall = Array{Float64}(undef, m_wall);
#   ======================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = f_wall_node(m_wall);

    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_L_update_diag!(L, N_H, v1, H_East);
    #   Ground state of -H = anti-ground state of H
    H_East .*= -1.0;

    #   Anti-ground state using wall-Chebyshev method
    EG, j_wall = f_Wall!(0.5, E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1);

    #   Ansatz of Eq. (8)
    theta_arr = fill(5*π/3, L); theta_arr[L] = 4*π/3;
    v1 .= f_spin_c_state(L, theta_arr);
    olap = dot(v0, v1);
    fname = @sprintf("%s_%s_%02d.dat", ftype, "spin-c_AS_overlap", L);
    writedlm(fname, olap^2, '\t');
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time_spin-c_olap.dat", "a") do io
    write(io, str);
end
