#   ===================================================
using SparseArrays, LinearAlgebra, Random, Polynomials, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule

include("/home/adway/01.Works/01.CPU/21.East/scripts/DOSModule.jl")  # loads the file with functions for DOS
using .DOSModule         # dot means “from current project/folder”
#   ===================================================
#=
    ⋅   1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
    ⋅   DOS

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   System parameters
s_arr = collect(-1:0.1:1); # vcat(collect(-1:0.1:-0.1), collect(-0.08:0.02:0.08), collect(0.1:0.1:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
fid_s_vals = open(fname_s_vals, "w");
writedlm(fid_s_vals, s_arr, '\t'); close(fid_s_vals);
#   ===================================================
#   Internal parameters
const Nv = 64;      #   Number of stochastic samplings
#   Number of Lanczos steps
const m = max( 256, convert(Int64, floor(sqrt(N_H))) );
#   Number of points in the energy axis
const lEx = 64;
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);

#   Arrays for DOS
E_edge = Array{Float64}(undef, lEx+1);
Ex = Array{Float64}(undef, lEx);
Ey = zeros(lEx);
z_wght = Array{Float64}(undef, m);

E_mom_arr = Array{Float64}(undef, 4);
#   ======================================
stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    #   Filesnaem for energy moments
    fname_e_mom = @sprintf("%s_%s_%02d.dat", ftype, "E_mom", L);
    fid_e_mom = open(fname_e_mom, "w");

    for s in s_arr          #   Loop for system parameter
        @printf("s: %+5.2f\n", s);
        global Γ = exp(s);

        #   Update diagonal part of East Hamiltonian
        global E_East, ax, j1, H_East;
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Calculate energy moments
        f_E_mom!(N_H, Nv, H_East, v0, v1, vk, E_mom_arr);
        #   Accounting for global factor in the Hamiltonian
        E_mom_arr[1] /= (2*Γ); E_mom_arr[2] /= (2*Γ)^2;
        E_mom_arr[3] /= (2*Γ)^3; E_mom_arr[4] /= (2*Γ)^4;
        #   Save energy moments
        writedlm(fid_e_mom, [s; E_mom_arr]', '\t');

        #   DOS from m-step Lanczos reduction
        global v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm, Ex, E_edge, z_wght, Ey;
        f_DOS_Lanczos!(N_H, m, Nv, lEx, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm, Ex, Ey, E_edge, z_wght);
        #   Accounting for global factor in the Hamiltonian
        Ex ./= 2*Γ; Ey .*= 2*Γ;

        #   Save DOS data
        fname_DOS = @sprintf("%s_%s_%02d_%+5.2f.dat", ftype, "DOS", L, s);
        fid_DOS = open(fname_DOS, "w");
        writedlm(fid_DOS, hcat(Ex, Ey), '\t'); close(fid_DOS);
    end                     #   Loop for system parameter closed
    close(fid_e_mom);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end