clear; close all;
%===============================
%   Spectral function for pi-pulse perturbation
ftype = "East"; qtype = "spectral_pi_pulse";
Larr = 12:2:12; len = length(Larr);
%   Broadening parameter
eta = 0.9;
%   Lorentz distribution
f_Lorentz = @(x0, eta, x) ((eta/pi) ./ (eta^2 + (x-x0).^2));

G_arr = zeros(1, len);
E_arr = zeros(1, len);
spctrl_cell = cell(1, len);

for iL = 1:len
    L = Larr(iL);
    fname = sprintf("%s_%s_%02d.dat", ftype, qtype, L);
    M = readmatrix(fname);

    %   Discarding large frequencies
    ix = find(M(:, 1) > 10, 1);

    Ex = M(1:ix, 1); wght = M(1:ix, 2);
    lEx = length(Ex);

    %   Spectral function
    y = zeros(lEx, 1);
    for j = 1:lEx
        yy = wght(j) .* f_Lorentz(Ex(j), eta, Ex);
        y = y + yy;
    end
    nrm = trapz(Ex, y); y = y./nrm;
    spctrl_cell{iL} = [Ex'; y'];

    %   Energy of the edge mode
    [~, i] = max(y); E_arr(iL) = Ex(i);
    %   Inverse lifetime of the edge mode
    Gamma = sqrt(trapz(Ex, (Ex.^2).*y) - trapz(Ex, Ex.*y)^2);
    G_arr(iL) = Gamma;
end
%=====================================================
fname = sprintf('%s_%s.mat', ftype, qtype);
save(fname, 'Larr', 'spctrl_cell', 'G_arr', 'E_arr');