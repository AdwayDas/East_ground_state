include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
include("/home/adway/01.Works/01.CPU/21.East/scripts/DynamicsModule.jl")
using .H_EastModule, .DynamicsModule, LinearAlgebra, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with East boundary condition
    ⋅   Survival probability of edge mode
    ⋅   Exact: full diagonalization, R(t) = |Σₙ |<Eₙ|Ψ>|² e^{-iEₙt}|² (valid at all t, up to t_H²).
        A single m-step Lanczos basis (f_SP_Lanczos!, used before) is only accurate for t ≲ 5-20.
        Dense ED needs 8·4^L bytes: L ≤ 14 on a 16 GB machine (L = 16 needs ~32 GB).

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   Time
tH = 2^L/sqrt(L/2+3/4); log_tH = log10(tH);                #   Heisenberg time
const t_arr = 10 .^ collect(range(-1, 2*log_tH; length=2^10)); const lt = length(t_arr);
fname_t = @sprintf("%s_%02d.dat", "time", L);
writedlm(fname_t, t_arr, '\n');

#   System parameters
s_arr = [-4; -1; -0.2; 0; 0.1; 0.2; 0.4; 1];

#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
writedlm(fname_s_vals, s_arr, '\t');

#   ======================================
#   Preallocate arrays
E_East = zeros(N_H)
H_East_dense = zeros(N_H, N_H)
#   Weights |<Eₙ|Ψ>|²
vα = Vector{Float64}(undef, N_H)
#   Initial state
Ψ = Vector{Float64}(undef, N_H)
SP_arr = Vector{Float64}(undef, lt)
#   ======================================
#   Filename
fname_SP_c = @sprintf("%s_%s_%02d.dat", ftype, "SP_spin-c", L);
fid_SP_c = open(fname_SP_c, "w");

stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    #   Spin-coherent state: edge mode for s -> -∞
    #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
    theta_arr = zeros(L); fill!(theta_arr, π/3); theta_arr[1] = 4*π/3
    Ψ = f_spin_c_state(L, theta_arr);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s); println("s: ", s);

        #   Update diagonal part of East Hamiltonian
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Exact diagonalization
        V_East = f_ED!(N_H, H_East_dense, H_East, E_East);
        mul!(vα, transpose(V_East), Ψ); vα .= abs2.(vα);

        #   Survival probability, R(t) = |Σₙ |<Eₙ|Ψ>|² e^{-iEₙt}|²
        @inbounds for jt in 1:lt
            amp = zero(ComplexF64)
            @simd for n in 1:N_H
                amp += vα[n] * cis(-t_arr[jt] * E_East[n])
            end
            SP_arr[jt] = abs2(amp)
        end
        
        #   Store data
        writedlm(fid_SP_c, transpose(SP_arr), '\t');
        
    end
    close(fid_SP_c);
    
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end