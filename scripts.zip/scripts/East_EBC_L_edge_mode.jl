include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
#   Functions for ground state
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")

using .H_EastModule, .GSModule, DelimitedFiles, Printf

#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Verification of edge mode

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;
#   ===================================================
#   Internal parameters
#   ===================================================
#   Estimtes for lower and upper bounds of spectrum
E_low = -1 - sqrt(3)*(3*L+1)/8; E_up = 1 + sqrt(3)*(3*L+1)/8;
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   Number of Lanczos steps for spectral function
const m_spectral = 256 + (L-10)*16;
#   ======================================
#   Preallocate arrays
v0 = zeros(N_H);
v1 = zeros(N_H);
v2 = zeros(N_H);
a_wall = Array{Float64}(undef, m_wall);
#   ===================================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = f_wall_node(m_wall);

    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_L_update_diag!(L, N_H, v1, H_East);

    #   Ground state using wall-Chebyshev method
    EG, j_wall = f_Wall!(0.5, E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1);

    #   π-pulse on the ground state around Y-axis on the first site (creates |•_1>)
    v1 .= f_pi_pulse_Y(L, 1, v0);

    #   m-step Lanczos reduction starting from the π-pulsed state
    m_eff, E_Tm, V_Tm = f_m_Lanczos_v0!(N_H, m_spectral, H_East, v1);

    #   Store data for spectral function
    fname = @sprintf("%s_%s_%02d.dat", ftype, "spectral_pi_pulse", L);
    writedlm(fname, [E_Tm .- EG V_Tm[1, :].^2], '\t');
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end

