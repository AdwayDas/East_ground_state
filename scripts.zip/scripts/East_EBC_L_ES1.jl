#   ===================================================
using Arpack, Optim, LinearAlgebra, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")  # loads the file with ground state functions
using .GSModule
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Excited state with low entanglement

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
#   Define functions
#   ===================================================
#   Spin-coherent states: H_EastModule.f_spin_c_state, f_spin_pol_state
#   ===================================================
#   End of function definitions
#   ===================================================
ftype = "East_L_ES1";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   q values for Dq analysis
const qx = vcat(collect(0:0.1:1-0.1), collect(1+0.1:0.1:5), collect(6:30));
const lq = length(qx);
logL_qx = log(N_H).*(1 .- qx);
fname_qx = @sprintf("%s.dat", "qx");
fid_qx = open(fname_qx, "w");
writedlm(fid_qx, qx, '\t'); close(fid_qx);

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B

#   Energy of the target state
E_trgt = 1.299 - 0.6687*L
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
v1 = zeros(N_H);
n_arr = Array{Float64}(undef, L);
n_corr = Array{Float64}(undef, L-1);
Dq_arr = Array{Float64}(undef, lq);
v_to_M = zeros(NA, NB);
#   ======================================
#   Filenames
#   ======================================
#   Energy
fname_E = @sprintf("%s_%s_%02d.dat", ftype, "E", L);
fid_E = open(fname_E, "w");

#   Number density
fname_n_dnsty = @sprintf("%s_%s_%02d.dat", ftype, "n_dnsty", L);
fid_n_dnsty = open(fname_n_dnsty, "w");

#   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ>
fname_n_nr = @sprintf("%s_%s_%02d.dat", ftype, "n_nr", L);
fid_n_nr = open(fname_n_nr, "w");

#   Magnetization in X-direction, <σˣᵢ>
fname_sx = @sprintf("%s_%s_%02d.dat", ftype, "sx", L);
fid_sx = open(fname_sx, "w");

#   Fractal dimensions
fname_Dq = @sprintf("%s_%s_%02d.dat", ftype, "Dq", L);
fname_Dmax = @sprintf("%s_%s_%02d.dat", ftype, "Dmax", L);
fid_Dq = open(fname_Dq, "w");
fid_Dmax = open(fname_Dmax, "w");

#   Fractal dimensions in σˣ basis
fname_Dq_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dq_sx", L);
fname_Dmax_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dmax_sx", L);
fid_Dq_sx = open(fname_Dq_sx, "w");
fid_Dmax_sx = open(fname_Dmax_sx, "w");

#   von Neumann entanglement entropy
fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN", L);
fid_SvN = open(fname_SvN, "w");
#   ======================================
stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);
    
    #   Shift-invert
    E_arr, V_M = eigs(H_East, nev=1, which=:LM, tol=0.0, sigma=E_trgt, ritzvec=true);
    E_val = E_arr[1]; v0 = V_M[:, 1];
    println("E_target: ", E_trgt, ", E_obtained: ", E_val);
    writedlm(fid_E, E_val, '\t'); close(fid_E);

    #   Finding spin-coherent state closest to v0
    fun_ovrlp(θ) = -abs2(dot(f_spin_c_state(L, θ), v0));

    #   Initial guess for θᵢ
    #   |ES1> ≈ |•_1>: π-rotated first spin (next to the fixed occupied site 0)
    theta_arr = zeros(L); fill!(theta_arr, pi/3); theta_arr[1] = 4*pi/3;

    res = optimize(fun_ovrlp, theta_arr, NelderMead())

    theta_min = mod.(Optim.minimizer(res), 2*pi); 
    # neg_ovrlp = Optim.minimum(res)

    fname_theta = @sprintf("%s_%s_%02d.dat", ftype, "theta_min", L);
    writedlm(fname_theta, theta_min, '\t');

    #   Overlap with the ansatz |•_1> (Eq. (6) of the paper; the initial guess)
    olap = abs2(dot(f_spin_c_state(L, theta_arr), v0))
    fname = @sprintf("%s_%s_%02d.dat", ftype, "spin-c_overlap", L);
    writedlm(fname, olap, '\t');

    #   Overlap with the optimised spin-coherent state (angles theta_min)
    olap_opt = abs2(dot(f_spin_c_state(L, theta_min), v0))
    fname = @sprintf("%s_%s_%02d.dat", ftype, "spin-c_opt_overlap", L);
    writedlm(fname, olap_opt, '\t');
    println("|<ES1|•_1>|² = ", olap, ",  optimised: ", olap_opt)

    #   ======================================
    #   Observables
    #   ======================================
    #   Number density, <nᵢ>
    global n_arr;
    f_num_dnsty!(L, N_H, v0, n_arr);
    writedlm(fid_n_dnsty, n_arr', '\t'); close(fid_n_dnsty);

    #   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ>
    global n_corr;
    f_dnsty_corr!(L, N_H, v0, n_arr, n_corr);
    writedlm(fid_n_nr, n_corr', '\t'); close(fid_n_nr);

    #   Magnetization in X-direction, <σˣᵢ>
    f_sx_avg!(L, N_H, v0, n_arr);
    writedlm(fid_sx, n_arr', '\t'); close(fid_sx);

    println(n_arr')

    #   Fractal dimensions
    Dmax = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq, Dq_arr', '\t'); close(fid_Dq);
    writedlm(fid_Dmax, Dmax, '\t'); close(fid_Dmax);

    #   Bipartite von Neumann entanglement entropy
    SvN = f_SvN!(L, v0, v_to_M);
    writedlm(fid_SvN, SvN, '\t'); close(fid_SvN);

    #   Represent the ground state in σˣ basis
    trnsfrm_sz_to_sx!(N_H, v0);

    #   Fractal dimensions in σˣ basis
    Dmax_sx = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
    writedlm(fid_Dq_sx, Dq_arr', '\t'); close(fid_Dq_sx);
    writedlm(fid_Dmax_sx, Dmax_sx, '\t'); close(fid_Dmax_sx);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end