#   ===================================================
using SparseArrays, LinearAlgebra, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule

include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")  # loads the file with ground state functions
using .GSModule         # dot means “from current project/folder”
#   ===================================================
#=
    ⋅   1D East model with East boundary condition (DOI: 10.1103/j7jf-746f)
    ⋅   Ground state properties

    ---Parameter descriptions---
    L = Number of particles
    s = system parameter
=#
#   ===================================================
ftype = "East";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

#   System parameters
s_arr = vcat(collect(-1:0.1:-0.1), collect(-0.08:0.02:0.08), collect(0.1:0.1:1));
#   Save s values
fname_s_vals = @sprintf("%s_%s_%02d.dat", ftype, "s_vals", L);
fid_s_vals = open(fname_s_vals, "w");
writedlm(fid_s_vals, s_arr, '\t'); close(fid_s_vals);

#   q values for Dq analysis
const qx = vcat(collect(0:0.1:1-0.1), collect(1+0.1:0.1:5), collect(6:30));
const lq = length(qx);
logL_qx = log(N_H).*(1 .- qx);
fname_qx = @sprintf("%s.dat", "qx");
fid_qx = open(fname_qx, "w");
writedlm(fid_qx, qx, '\t'); close(fid_qx);

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B
#   ===================================================
#   Internal parameters
const Nv = 8;   #   Number of repetitions for m-step Lanczos
const m = 16;   #   Number of Lanczos steps
#   Precision in energy estimate
const E_tol = 1e-12;
#   Number of wall-Chebyshev nodes; max number of projections
const m_wall = 32; const n_wall = max(256, div(N_H, 16));
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);
#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);

a_wall = Array{Float64}(undef, m_wall);
n_arr = Array{Float64}(undef, L);
n_corr = Array{Float64}(undef, L-1);
Dq_arr = Array{Float64}(undef, lq);
v_to_M = zeros(NA, NB);
#   ======================================
#   Filenames
#   ======================================
#   Ground state energy
fname_E_GS = @sprintf("%s_%s_%02d.dat", ftype, "E_GS", L);
fid_E_GS = open(fname_E_GS, "w");

#   Number density w.r.t. ground state
fname_n_dnsty = @sprintf("%s_%s_%02d.dat", ftype, "n_dnsty_GS", L);
fid_n_dnsty = open(fname_n_dnsty, "w");

#   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ> w.r.t. ground state
fname_n_nr = @sprintf("%s_%s_%02d.dat", ftype, "n_nr_GS", L);
fid_n_nr = open(fname_n_nr, "w");

#   Magnetization in X-direction, <σˣᵢ> w.r.t. ground state
fname_sx = @sprintf("%s_%s_%02d.dat", ftype, "sx_GS", L);
fid_sx = open(fname_sx, "w");

#   Fractal dimensions
fname_Dq = @sprintf("%s_%s_%02d.dat", ftype, "Dq", L);
fname_Dmax = @sprintf("%s_%s_%02d.dat", ftype, "Dmax", L);
fid_Dq = open(fname_Dq, "w");
fid_Dmax = open(fname_Dmax, "w");

#   Fractal dimensions in σˣ basis
fname_Dq_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dq_sx", L);
fname_Dmax_sx = @sprintf("%s_%s_%02d.dat", ftype, "Dmax_sx", L);
fid_Dq_sx = open(fname_Dq_sx, "w");
fid_Dmax_sx = open(fname_Dmax_sx, "w");

#   von Neumann entanglement entropy
fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN", L);
fid_SvN = open(fname_SvN, "w");
#   ======================================
stats = @timed begin
    #   Scaled wall-Chebyshev nodes
    a_wall_scld = f_wall_node(m_wall);
    #   ==================================
    #   Off-diagonal part of East Hamiltonian
    H_East = f_H_East_EBC_off(L, N_H);

    for s in s_arr          #   Loop for system parameter
        global Γ = exp(s);

        #   Update diagonal part of East Hamiltonian
        global E_East, H_East;
        f_H_East_EBC_update_diag!(L, N_H, Γ, E_East, H_East);

        #   Estimate energy bounds from m-step Lanczos reduction
        global v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm;
        E_low, E_up = f_E_bound_Lanczos!(N_H, m, Nv, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm);
        
        #   Ground state energy using wall-Chebyshev method
        global a_wall;
        EG, j_wall = f_Wall!(Γ, E_low, E_up, E_tol, m_wall, n_wall, H_East, a_wall_scld, a_wall, v0, v1);
        writedlm(fid_E_GS, [s EG], '\t');

        #   Number density, <nᵢ> w.r.t. ground state
        global n_arr;
        f_num_dnsty!(L, N_H, v0, n_arr);
        writedlm(fid_n_dnsty, n_arr', '\t');

        #   Connected density-density correlation, <n₁ n₁₊ᵣ> - <n₁><n₁₊ᵣ> w.r.t. ground state
        global n_corr;
        f_dnsty_corr!(L, N_H, v0, n_arr, n_corr);
        writedlm(fid_n_nr, n_corr', '\t');

        #   Magnetization in X-direction, <σˣᵢ> w.r.t. ground state
        f_sx_avg!(L, N_H, v0, n_arr);
        writedlm(fid_sx, n_arr', '\t');

        #   Fractal dimensions
        Dmax = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
        writedlm(fid_Dq, Dq_arr', '\t');
        writedlm(fid_Dmax, [s Dmax], '\t');

        #   Bipartite von Neumann entanglement entropy
        SvN = f_SvN!(L, v0, v_to_M);
        writedlm(fid_SvN, [s SvN], '\t');

        #   Represent the ground state in σˣ basis
        trnsfrm_sz_to_sx!(N_H, v0);

        #   Fractal dimensions in σˣ basis
        Dmax_sx = f_Dq!(N_H, lq, v0, v1, qx, logL_qx, Dq_arr);
        writedlm(fid_Dq_sx, Dq_arr', '\t');
        writedlm(fid_Dmax_sx, [s Dmax_sx], '\t');
    end                     #   Loop for system parameter closed
    close(fid_E_GS);
    close(fid_n_dnsty);
    close(fid_n_nr);
    close(fid_sx);
    close(fid_Dq);
    close(fid_Dmax);
    close(fid_SvN);
    close(fid_Dq_sx);
    close(fid_Dmax_sx); 
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end