module DynamicsModule

#   Hamiltonian of East model with East boundary conditions
export f_SP_ED_Fock!, f_SP_ED!, normalized_power_spectrum, f_SP_expo!, f_dynamics_expo!, f_dynamics_ED!,
    f_SP_Lanczos!, f_LDOS_Lanczos!

using SparseArrays, LinearAlgebra, Random, StatsBase, FFTW, Expokit, LinearMaps

#   ===================================================
#   Number density, <nᵢ>
#   ===================================================
function f_num_dnsty!(L::Int, N_H::Int, v0::Vector{ComplexF64}, n_arr::Vector{Float64})
    fill!(n_arr, 0.0)
    @inbounds for state in 0:(N_H - 1)
        s = UInt64(state)
        val = abs2(v0[state + 1])

        while s != 0
            b = s & (-s)                 # isolate lowest 1-bit
            # bit (j-1) ↔ site j, as in H_EastModule
            j = trailing_zeros(b) + 1

            n_arr[j] += val

            s &= s - 1                   # clear lowest 1-bit
        end
    end
end
#   ===================================================
#   Magnetization in X-direction, <σˣᵢ> w.r.t. ground state
#   ===================================================
function f_sx_avg!(L::Int, N_H::Int, v0::Vector{ComplexF64}, sx_arr::Vector{ComplexF64})
    fill!(sx_arr, complex(0.0, 0.0))

    #   No @simd: every iteration accumulates into the same sx_arr entries
    @inbounds for state in 0:(N_H - 1)
        v = conj(v0[state + 1])
        s = UInt(state)

        @inbounds for i in 1:L
            #   flip spin at site i (bit i-1) via XOR
            s_flip = xor(s, UInt(1) << (i - 1))
            #   <σˣᵢ> contribution
            sx_arr[i] += v * v0[Int(s_flip) + 1]
        end
    end
end
#   ===================================================
#   Bipartite von Neumann entanglement entropy
#   ===================================================
function f_SvN!(L::Int, v::Vector{ComplexF64}, v_to_M::Matrix{ComplexF64})
    NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
    NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B

    copyto!(v_to_M, reshape(v, NA, NB));

    #   Singular value decomposition
    S = svd(v_to_M; full = false);
    s_vals = S.S;

    #   Compute von Neumann entanglement entropy
    SvN = 0.0;
    @inbounds for s in s_vals
        p = abs2(s)
        if p > 0
            SvN -= p * log(p)
        end
    end

    return SvN;
end
#   ===================================================
#   Survival probability of a Fock state from exact diagonalization data
#   ===================================================
function f_SP_ED_Fock!(N_H::Int64, α::Int, lt::Int64,
    E_arr::Vector{Float64}, V_M::Matrix{Float64},
    t_arr::Vector{Float64}, tmp::Vector{ComplexF64}, Ψt::Vector{ComplexF64},
    SP_arr::Vector{Float64}
)
    # Precompute the coefficients V[α,n]
    vα = @view V_M[α, :]

    @inbounds for jt in 1:lt
        t = t_arr[jt]

        # fill tmp(t) without branches
        @inbounds @simd for n in 1:N_H
            tmp[n] = vα[n] * cis(-t * E_arr[n])
        end

        # Ψt = V * tmp   (BLAS)
        mul!(Ψt, V_M, tmp)

        # survival probability
        SP_arr[jt] = abs2(Ψt[α])
    end

    # equilibrium survival probability ∑ V[α,n]^4
    SP_bar = 0.0
    @inbounds @simd for n in 1:N_H
        SP_bar += vα[n]^4
    end

    return SP_bar
end
#   ===================================================
#   Survival probability of an arbitrary initial state
#   ===================================================
function f_SP_ED!(N_H::Int, Ψ::Vector{Float64}, lt::Int,
    E_arr::Vector{Float64}, V_M::Matrix{Float64},
    vα::Vector{Float64}, t_arr::Vector{Float64},
    tmp::Vector{ComplexF64}, Ψt::Vector{ComplexF64},
    SP_arr::Vector{Float64}
)

    # --- 1) Precompute overlaps   vα[n] = <E_n | Ψ>
    # BLAS: vα = V_M' * Ψ
    mul!(vα, transpose(V_M), Ψ)

    # --- 2) Survival probability over times ---
    @inbounds for jt in 1:lt
        t = t_arr[jt]

        @inbounds @simd for n in 1:N_H
            @fastmath tmp[n] = vα[n] * cis(-t * E_arr[n])
        end

        # Ψ(t) = V * tmp   (BLAS)
        mul!(Ψt, V_M, tmp)

        # | <Ψ | Ψ(t)> |^2
        SP_arr[jt] = abs2(dot(Ψt, Ψ))
    end

    # --- 3) Equilibrium survival probability ---
    SP_bar = 0.0
    @inbounds @simd for n in 1:N_H
        SP_bar = @fastmath SP_bar + vα[n]^4
    end

    return SP_bar
end
#   ===================================================
#   Survival probability of an arbitrary initial state using Expokit
#   ===================================================
function f_SP_expo!(A, Ψ::Vector{Float64},
               dt::Float64, lt::Int, anorm_est::Float64,
               tmp::Vector{ComplexF64}, Ψt::Vector{ComplexF64},
               SP_arr::Vector{Float64})

    # Copy initial state into Ψt
    copyto!(Ψt, Ψ)

    SP_arr[1] = 1.0

    # Use a single output buffer for expmv! to avoid swapping
    @inbounds for i in 2:lt
        # Compute next time step in tmp
        expmv!(tmp, dt, A, Ψt; m=30, tol=1e-12, anorm=anorm_est)

        # Compute overlap before overwriting Ψt
        SP_arr[i] = abs2(dot(tmp, Ψ))

        # Copy tmp back into Ψt in-place
        copyto!(Ψt, tmp)
    end

    return nothing
end
#   ===================================================
#   Dynamics using Expokit
#   ===================================================
function f_dynamics_expo!(L::Int, N_H::Int, A, Ψ::Vector{Float64},
               dt::Float64, lt::Int, anorm_est::Float64,
               tmp::Vector{ComplexF64}, Ψt::Vector{ComplexF64},
               SP_arr::Vector{Float64}, n_M::Matrix{Float64},
               sx_M::Matrix{ComplexF64}, SvN_arr::Vector{Float64},
               v_to_M::Matrix{ComplexF64})

    #   Copy initial state into Ψt
    copyto!(Ψt, Ψ)

    #   Initial expectation values
    #   Survival probability
    SP_arr[1] = 1.0
    #   Number density
    n_arr = zeros(L); f_num_dnsty!(L, N_H, Ψt, n_arr);
    copyto!(@view(n_M[1, :]), n_arr);
    #   Magnetization in X-direction
    sx_arr = zeros(ComplexF64, L); f_sx_avg!(L, N_H, Ψt, sx_arr);
    copyto!(@view(sx_M[1, :]), sx_arr);
    #   Bipartite von Neumann entanglement entropy
    SvN = f_SvN!(L, Ψt, v_to_M);
    SvN_arr[1] = SvN

    @inbounds for i in 2:lt
        #   Compute next time step in tmp
        expmv!(tmp, dt, A, Ψt; m=30, tol=1e-12, anorm=anorm_est)

        # Copy tmp back into Ψt in-place, so all observables below are at t_arr[i]
        copyto!(Ψt, tmp)

        #   Survival probability
        SP_arr[i] = abs2(dot(Ψt, Ψ))
        #   Number density
        f_num_dnsty!(L, N_H, Ψt, n_arr);
        copyto!(@view(n_M[i, :]), n_arr);
        #   Magnetization in X-direction
        f_sx_avg!(L, N_H, Ψt, sx_arr);
        copyto!(@view(sx_M[i, :]), sx_arr);
        #   Bipartite von Neumann entanglement entropy
        SvN = f_SvN!(L, Ψt, v_to_M);
        SvN_arr[i] = SvN
    end

    return nothing
end
#   ===================================================
#   Dynamics using exact diagonalization
#   ===================================================
function f_dynamics_ED!(L::Int, N_H::Int, V_M::Matrix{Float64}, E_arr::Vector{Float64},
               lt::Int, t_arr::Vector{Float64}, Ψ::Vector{Float64}, vα::Vector{Float64},
               tmp::Vector{ComplexF64}, Ψt::Vector{ComplexF64},
               SP_arr::Vector{Float64}, n_M::Matrix{Float64},
               sx_M::Matrix{ComplexF64}) #, SvN_arr::Vector{Float64}, v_to_M::Matrix{ComplexF64})

    #   <E_n | Ψ>        
    mul!(vα, transpose(V_M), Ψ)

    n_arr = zeros(L); sx_arr = zeros(ComplexF64, L);
    @inbounds for i in 1:lt
        t = t_arr[i]

        @inbounds @simd for n in 1:N_H
            @fastmath tmp[n] = vα[n] * cis(-t * E_arr[n])
        end

        # Ψ(t) = V * tmp   (BLAS)
        mul!(Ψt, V_M, tmp)

        #   Survival probability
        SP_arr[i] = abs2(dot(Ψt, Ψ))
        #   Number density
        f_num_dnsty!(L, N_H, Ψt, n_arr);
        copyto!(@view(n_M[i, :]), n_arr);
        #   Magnetization in X-direction
        f_sx_avg!(L, N_H, Ψt, sx_arr);
        copyto!(@view(sx_M[i, :]), sx_arr);
        # #   Bipartite von Neumann entanglement entropy
        # SvN = f_SvN!(L, Ψt, v_to_M);
        # SvN_arr[i] = SvN
    end

    return nothing
end
#   ===================================================
#   m-step Lanczos reduction
#   ===================================================
function f_m_Lanczos(N::Int, m::Int,
    H::SparseMatrixCSC{Float64, Int},
    Ψ::Vector{Float64}
)
    #   Work vectors (initial vector normalized, as in H_EastModule.f_m_Lanczos_v0!)
    v0 = normalize(Ψ); v1 = similar(v0); vk = similar(v0)
    #   Tolerance value for stopping Lanczos iteration
    tol = sqrt(eps(Float64))
    #   Krylov basis (N × m)
    Qm = Array{Float64}(undef, N, m)
    #   Tridiagonal matrix in the Krylov space
    pot = Array{Float64}(undef, m)
    hop = Array{Float64}(undef, m)

    @views copyto!(Qm[:,1], v0)

    # vk = H * q1
    mul!(vk, H, v0)

    # a1
    ak = dot(v0, vk)
    pot[1] = ak

    # vk -= a1 * q1
    @inbounds @. vk -= ak * v0

    # b1
    bk = norm(vk)

    # effective Lanczos dimension
    m_eff = 1

    if bk < tol
        hop .= 0.0
    else
        hop[1] = bk
        copyto!(v1, v0)   # q_{j-1} = q1

        # --- Lanczos loop ---
        for j in 2:m
            # q_j = vk / b_{j-1}
            @inbounds @. v0 = vk / bk
            @views copyto!(Qm[:, j], v0)

            # vk = H * q_j
            mul!(vk, H, v0)

            # vk -= b_{j-1} * q_{j-1}
            @inbounds @. vk -= bk * v1

            # a_j
            ak = dot(v0, vk)
            pot[j] = ak

            # vk -= a_j * q_j
            @inbounds @. vk -= ak * v0

            # --- full reorthogonalization ---
            for iQ in 1:(j-1)
                @views q = Qm[:, iQ]
                c = dot(q, vk)
                LinearAlgebra.BLAS.axpy!(-c, q, vk)
            end

            # b_j
            bk = norm(vk)
            m_eff = j

            if bk < tol
                break
            end

            hop[j] = bk
            copyto!(v1, v0)
        end
    end

    # --- build Tm (only up to m_eff) ---
    # A zero-padded m × m matrix would add spurious zero Ritz values
    Tm = SymTridiagonal(pot[1:m_eff], hop[1:(m_eff-1)])

    # --- eigen-decomposition ---
    egn = eigen!(Tm)

    return m_eff, egn.values, egn.vectors, Qm[:, 1:m_eff]
end
#   ===================================================
#   Lanczos-Krylov time evolution
#   Ψt = Qm * (V_Tm * (exp.(-1im * E_Tm * t) .* V_Tm[1, :]))
#   ===================================================
function f_SP_Lanczos!(
    N::Int,
    m::Int,
    H::SparseMatrixCSC{Float64, Int},
    Ψ::Vector{Float64},
    t_arr::Vector{Float64},
    SP_arr::Vector{Float64}
)
    #   Effective Krylov dimension, Ritz values and vectors, Krylov basis
    m_eff, E_Tm, V_Tm, Qm = f_m_Lanczos(N, m, H, Ψ)

    # Precompute weights |V_{1k}|^2
    weights = @views abs2.(V_Tm[1, 1:m_eff])

    @inbounds for jt in eachindex(t_arr)
        t = t_arr[jt]

        # overlap = ⟨Ψ|Ψ(t)⟩
        s = ComplexF64(0.0, 0.0)
        @simd for k in 1:m_eff
            s += weights[k] * cis(-E_Tm[k] * t)
        end

        SP_arr[jt] = abs2(s)
    end

    return nothing
end
#   ===================================================
#   Normalized power-spectrum
#   ===================================================
function normalized_power_spectrum(lt::Int, x::Vector{Float64})
    X = fft(x)

    P = abs2.(X)

    # Keep positive frequencies for real input
    P = P[1:div(lt,2)+1]

    # Normalize total power to 1
    P ./ sum(P)
end
#   ===================================================
#   LDOS from m-step Lanczos reduction
#   ===================================================
function f_LDOS_Lanczos!(N::Int, m::Int, Nv::Int, lEx::Int,
    M::SparseMatrixCSC{Float64,Int}, v0::Vector{Float64}, v1::Vector{Float64},
    vk::Vector{Float64}, Qm::Matrix{Float64}, pot::Vector{Float64},
    hop::Vector{Float64}, Tm::SymTridiagonal{Float64,Vector{Float64}},
    E_Tm::Vector{Float64}, V_Tm::Matrix{Float64}, Ex::Vector{Float64},
    Ey::Vector{Float64}, E_edge::Vector{Float64}, z_wght::Vector{Float64})

    dE = 0.0
    E_up = 0.0
    E_low = 0.0
    E_max = 0.0
    ak = 0.0
    bk = 0.0

    @simd for i in 1:N
        bk += v0[i]^2
    end
    bk = sqrt(bk)

    invbk = 1/bk
    @simd for i in 1:N
        v0[i] *= invbk
        Qm[i,1] = v0[i]
    end

    #----------------------------------------
    # First Lanczos coefficient
    mul!(vk, M, v0)

    ak = 0.0
    @simd for i in 1:N
        ak += v0[i] * vk[i]
    end
    pot[1] = ak

    @simd for i in 1:N
        vk[i] -= ak * v0[i]
    end

    bk = 0.0
    @simd for i in 1:N
        bk += vk[i]^2
    end
    bk = sqrt(bk)
    hop[1] = bk

    #----------------------------------------
    # Main Lanczos loop
    @inbounds for j in 2:m
        # v1 = previous v0
        @simd for i in 1:N
            v1[i] = v0[i]
        end

        # v0 = new normalized vk
        invbk = 1/bk
        @simd for i in 1:N
            v0[i] = vk[i] * invbk
            Qm[i,j] = v0[i]
        end

        mul!(vk, M, v0)

        # vk = vk - bk * v1
        @simd for i in 1:N
            vk[i] -= bk * v1[i]
        end

        # ak = dot(v0, vk)
        ak = 0.0
        @simd for i in 1:N
            ak += v0[i] * vk[i]
        end
        pot[j] = ak

        # vk -= ak * v0
        @simd for i in 1:N
            vk[i] -= ak * v0[i]
        end

        # Full Gram-Schmidt
        @inbounds for q in 1:j-1
            dq = 0.0
            colQ = @view Qm[:,q]   # does NOT allocate (view on matrix)
            @simd for i in 1:N
                dq += colQ[i] * vk[i]
            end
            @simd for i in 1:N
                vk[i] -= dq * colQ[i]
            end
        end

        # Next bk
        bk = 0.0
        @simd for i in 1:N
            bk += vk[i]^2
        end
        bk = sqrt(bk)
        hop[j] = bk
    end

    #----------------------------------------
    # Build Tm in-place (NO allocation)
    @inbounds for i in 1:m
        Tm.dv[i] = pot[i]
    end
    @inbounds for i in 1:m-1
        Tm.ev[i] = hop[i]
    end

    E_strc = eigen(Tm)           # allocates small arrays of size m
    @inbounds for i in 1:m
        E_Tm[i] = E_strc.values[i]
    end
    copyto!(view(V_Tm, 1:m, 1:m), E_strc.vectors)
    #----------------------------------------
    # Energy range (only first random vector)
    E_up = E_Tm[m] + hop[m] * abs(V_Tm[m,m])
    E_low = E_Tm[1] - hop[m] * abs(V_Tm[m,1])

    # bin edges
    ΔE = (E_up - E_low) / lEx
    cur = E_low
    @inbounds for i in 1:lEx+1
        E_edge[i] = cur
        cur += ΔE
    end

    # midpoints
    @inbounds for i in 1:lEx
        Ex[i] = 0.5 * (E_edge[i] + E_edge[i+1])
    end

    #----------------------------------------
    # Compute weights: z_wght[j] = V_Tm[1,j]^2
    @inbounds @simd for j in 1:m
        z_wght[j] = V_Tm[1,j] * V_Tm[1,j]
    end

    dE = Ex[2] - Ex[1]

    #----------------------------------------
    # Add Lorentzian broadened peaks
    @inbounds for j in 1:m
        ej = E_Tm[j]
        w = z_wght[j] * dE / π
        @inbounds @simd for i in 1:lEx
            Ey[i] += w / (dE^2 + (Ex[i] - ej)^2)
        end
    end
    
end
#   ===================================================
end # module DynamicsModule
#   ===================================================