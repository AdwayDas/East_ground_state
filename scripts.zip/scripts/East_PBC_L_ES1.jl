#   ===================================================
include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
#   Functions for ground state
include("/home/adway/01.Works/01.CPU/21.East/scripts/GSModule.jl")

using .H_EastModule, .GSModule, LinearAlgebra, Arpack, DelimitedFiles, Printf
#   ===================================================
#=
    ⋅   1D East model with periodic boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Excited state which may be close to momentum states

---Parameter descriptions---
L = Number of particles
=#
#   ===================================================
ftype = "East_L_PBC";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;

NA = 1 << (L ÷ 2);          #   Dimension of subsystem A
NB = 1 << (L - (L ÷ 2));    #   Dimension of subsystem B

#   Energy of the target state
E_trgt = sqrt(3)/4 - sqrt(27)*(L-1)/8
#   Number of states E_obtained
nev = 8
#   ======================================
#   Preallocate arrays
v = zeros(ComplexF64, N_H);
v_to_M = zeros(NA, NB);
#   ======================================
stats = @timed begin
    println("E_target: ", E_trgt);
    
    #   East Hamiltonian with PBC
    H_East = f_H_East_PBC_L(L, N_H);

    #   Shift-invert
    E_arr, V_M = eigs(H_East, nev=nev, which=:LM, tol=0.0, sigma=E_trgt, ritzvec=true);

    #   Printing data
    fname_E_East = @sprintf("%s_%s_%02d.dat", ftype, "E_ES1", L);
    writedlm(fname_E_East, E_arr, '\n');

    #   Bipartite von Neumann entanglement entropy
    fname_SvN = @sprintf("%s_%s_%02d.dat", ftype, "SvN_ES1", L);
    fid_SvN = open(fname_SvN, "w");

    @inbounds for n in 1:nev
        SvN = f_SvN!(L, V_M[:, n], v_to_M);
        writedlm(fid_SvN, SvN, '\t');
    end
    close(fid_SvN);

    #------------------------------
    #   Momentum states from spin-coherent states
    V_spin_c = zeros(N_H, L);
    theta_arr = zeros(L);
    #   Spin-coherent states
    @inbounds for j in 1:L
        fill!(theta_arr, π/3); theta_arr[j] = 4*π/3;
        V_spin_c[:, j] .= f_spin_c_state(L, theta_arr);
    end

    #   Momentum states
    olap_M = zeros(nev, L)
    @inbounds for k in 0:L-1
        fill!(v, 0.0);
        @inbounds for j in 1:L
            phase = 2*π*k*j/L
            v .+= exp(1im * phase) .* @view(V_spin_c[:, j])
        end
        v ./= sqrt(L)

        #   Overlap with eigenstates
        @inbounds for n in 1:nev
            olap_M[n, k+1] = abs2(dot(@view(V_M[:, n]), v))
        end
    end
    #   Printing data
    fname = @sprintf("%s_%s_%02d.dat", ftype, "olap_mom_state", L);
    writedlm(fname, olap_M, '\t');
end;

#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end
