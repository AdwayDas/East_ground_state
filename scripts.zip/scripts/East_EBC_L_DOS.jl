#   ===================================================
using SparseArrays, LinearAlgebra, Random, DelimitedFiles, Printf

include("/home/adway/01.Works/01.CPU/21.East/scripts/H_EastModule.jl")
using .H_EastModule
include("/home/adway/01.Works/01.CPU/21.East/scripts/DOSModule.jl")  # loads the file with functions for DOS
using .DOSModule
#   ===================================================
#=
    ⋅   1D East model with East boundary condition and s → -∞ (DOI: 10.1103/j7jf-746f)
    ⋅   Density of states

    ---Parameter descriptions---
    L = Number of particles
=#
#   ===================================================
ftype = "East_L";
const L = parse(Int64, ARGS[1]);        #   Number of sites

#   Hilbert space dimension
const N_H = 2^L;
#   ===================================================
#   Internal parameters
Nv = 64;      #   Number of stochastic samplings
#   Number of Lanczos steps
m = max( 256, convert(Int64, floor(sqrt(N_H))) );
#   Number of points in the energy axis
const lEx = 64;
#   ======================================
#   Preallocate arrays
E_East = zeros(N_H);

E_mom_arr = Array{Float64}(undef, 4);
#   Arrays for Lanczos algorithm
Qm = Array{Float64}(undef, N_H, m);
v0 = Array{Float64}(undef, N_H);
v1 = Array{Float64}(undef, N_H);
vk = Array{Float64}(undef, N_H);
pot = Array{Float64}(undef, m);
hop = Array{Float64}(undef, m);
Tm = SymTridiagonal(pot, hop[1:m-1]);
E_Tm = Array{Float64}(undef, m);
V_Tm = Array{Float64}(undef, m, m);
#   Arrays for DOS
E_edge = Array{Float64}(undef, lEx+1);
Ex = Array{Float64}(undef, lEx);
Ey = zeros(lEx);
z_wght = Array{Float64}(undef, m);
#   ======================================
stats = @timed begin
    #   Off-diagonal part of East Hamiltonian
    H_East = H_EastModule.f_H_East_EBC_L_off(L, N_H);

    #   Update diagonal part of East Hamiltonian
    E_East = zeros(Float64, N_H);
    H_EastModule.f_H_East_EBC_L_update_diag!(L, N_H, E_East, H_East);

    #   Calculate energy moments
    f_E_mom!(N_H, Nv, H_East, v0, v1, vk, E_mom_arr);
    #   Save energy moments
    fname_e_mom = @sprintf("%s_%s_%02d.dat", ftype, "E_mom", L);
    fid_e_mom = open(fname_e_mom, "w");
    writedlm(fid_e_mom, E_mom_arr', '\t'); close(fid_e_mom);

    #   DOS from m-step Lanczos reduction
    f_DOS_Lanczos!(N_H, m, Nv, lEx, H_East, v0, v1, vk, Qm, pot, hop, Tm, E_Tm, V_Tm, Ex, Ey, E_edge, z_wght);
    
    #   Save DOS data
    fname_DOS = @sprintf("%s_%s_%02d.dat", ftype, "DOS", L);
    fid_DOS = open(fname_DOS, "w");
    writedlm(fid_DOS, hcat(Ex, Ey), '\t'); close(fid_DOS);
end;
#   ======================================
#   Maximum resident set size in GB
Max_RSS = Sys.maxrss()/2^30;
#   Storing runtime and required memory
t_run = stats.time; t_run = t_run/60;
str = @sprintf("%2d\t%10.5f min\t%9.3f GiB\n", L, t_run, Max_RSS);
open("../run_time.dat", "a") do io
    write(io, str);
end